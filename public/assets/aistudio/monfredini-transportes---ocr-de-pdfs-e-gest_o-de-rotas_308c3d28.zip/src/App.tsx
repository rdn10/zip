import React, { useState, useEffect, useCallback } from 'react';
import { Logo } from './components/Logo.js';
import { ExcelTabBar } from './components/ExcelTabBar.js';
import { CoverDashboard } from './components/CoverDashboard.js';
import { RouteTable } from './components/RouteTable.js';
import { ImportModal } from './components/ImportModal.js';
import { ReviewModal } from './components/ReviewModal.js';
import { CitiesManager } from './components/CitiesManager.js';
import { ExportModal } from './components/ExportModal.js';
import { EditRouteModal } from './components/EditRouteModal.js';
import { City, RouteRecord, Stats, AppSettings } from './types.js';
import {
  FileUp,
  ClipboardCheck,
  Download,
  Building2,
  Columns,
  Maximize2,
  RefreshCw,
  Sparkles
} from 'lucide-react';

export default function App() {
  // State
  const [activeTab, setActiveTab] = useState<string>('INICIO');
  const [selectedCityName, setSelectedCityName] = useState<string>('RIO DE JANEIRO');
  const [viewMode, setViewMode] = useState<'SPLIT' | 'TABLE_ONLY' | 'COVER_ONLY'>('SPLIT');

  const [cities, setCities] = useState<City[]>([]);
  const [routes, setRoutes] = useState<RouteRecord[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalCities: 13,
    totalRoutes: 42,
    vehicleProfilesCount: 10,
    pendingReviews: 0,
    totalDocuments: 2,
    totalRecords: 140
  });
  const [settings, setSettings] = useState<AppSettings>({
    autoConfirmOcr: false,
    defaultClient: 'Mercado Livre',
    ocrModel: 'gemini-3.8-flash'
  });

  // Modals state
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [isCitiesModalOpen, setIsCitiesModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isEditRouteModalOpen, setIsEditRouteModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<RouteRecord | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);

  // Load data from backend
  const fetchData = useCallback(async () => {
    try {
      const [citiesRes, routesRes, statsRes, settingsRes] = await Promise.all([
        fetch('/api/cities'),
        fetch('/api/routes'),
        fetch('/api/stats'),
        fetch('/api/settings')
      ]);

      if (citiesRes.ok) {
        const citiesData = await citiesRes.json();
        setCities(citiesData);
        if (!selectedCityName && citiesData.length > 0) {
          setSelectedCityName(citiesData[0].name);
        }
      }

      if (routesRes.ok) {
        const routesData = await routesRes.json();
        setRoutes(routesData);
      }

      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }

      if (settingsRes.ok) {
        const settingsData = await settingsRes.json();
        setSettings(settingsData);
      }
    } catch (err) {
      console.error('Error fetching system data:', err);
    } finally {
      setIsLoading(false);
    }
  }, [selectedCityName]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Tab selection handler
  const handleSelectTab = (tab: string) => {
    if (tab === 'IMPORT') {
      setIsImportModalOpen(true);
    } else if (tab === 'REVIEW') {
      setIsReviewModalOpen(true);
    } else if (tab === 'CITIES') {
      setIsCitiesModalOpen(true);
    } else if (tab === 'INICIO') {
      setActiveTab('INICIO');
      setViewMode('SPLIT');
    } else {
      // City tab clicked
      setActiveTab(tab);
      setSelectedCityName(tab);
      setViewMode('TABLE_ONLY');
    }
  };

  // City selection from cover button or dropdown
  const handleSelectCityFromCover = (cityName: string) => {
    setSelectedCityName(cityName);
    setActiveTab(cityName);
    setViewMode('TABLE_ONLY');
  };

  // City selection inside route table dropdown
  const handleSelectCityInTable = (cityName: string) => {
    setSelectedCityName(cityName);
    if (activeTab !== 'INICIO') {
      setActiveTab(cityName);
    }
  };

  // Quick return to cover
  const handleGoHome = () => {
    setActiveTab('INICIO');
    setViewMode('SPLIT');
  };

  // Route operations
  const handleOpenEditRecord = (record: RouteRecord) => {
    setEditingRecord(record);
    setIsEditRouteModalOpen(true);
  };

  const handleOpenAddRecord = (originCity: string) => {
    setSelectedCityName(originCity);
    setEditingRecord(null);
    setIsEditRouteModalOpen(true);
  };

  const handleSaveRecord = async (recordData: Partial<RouteRecord> & { id?: string }) => {
    try {
      if (recordData.id) {
        // Edit
        const res = await fetch(`/api/routes/${recordData.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(recordData)
        });
        if (res.ok) {
          await fetchData();
        }
      } else {
        // Create
        const res = await fetch('/api/routes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(recordData)
        });
        if (res.ok) {
          await fetchData();
        }
      }
    } catch (err) {
      console.error('Error saving record:', err);
    }
  };

  const handleDeleteRecord = async (id: string) => {
    if (!confirm('Deseja realmente remover esta linha de rota?')) return;
    try {
      const res = await fetch(`/api/routes/${id}`, { method: 'DELETE' });
      if (res.ok) {
        await fetchData();
      }
    } catch (err) {
      console.error('Error deleting route record:', err);
    }
  };

  const handleBatchApprove = async (ids: string[]) => {
    try {
      const res = await fetch('/api/routes/batch-approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids })
      });
      if (res.ok) {
        await fetchData();
      }
    } catch (err) {
      console.error('Error approving records:', err);
    }
  };

  // City operations
  const handleAddCity = async (name: string, state: string, codes: string[]) => {
    try {
      const res = await fetch('/api/cities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, state, codes, active: true })
      });
      if (res.ok) {
        await fetchData();
      }
    } catch (err) {
      console.error('Error adding city:', err);
    }
  };

  const handleUpdateCity = async (id: string, updates: Partial<City>) => {
    try {
      const res = await fetch(`/api/cities/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        await fetchData();
      }
    } catch (err) {
      console.error('Error updating city:', err);
    }
  };

  const handleDeleteCity = async (id: string) => {
    if (!confirm('Deseja excluir esta cidade? As rotas associadas continuarão registradas.')) return;
    try {
      const res = await fetch(`/api/cities/${id}`, { method: 'DELETE' });
      if (res.ok) {
        await fetchData();
      }
    } catch (err) {
      console.error('Error deleting city:', err);
    }
  };

  // Settings
  const handleToggleAutoConfirm = async (val: boolean) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ autoConfirmOcr: val })
      });
      if (res.ok) {
        setSettings(prev => ({ ...prev, autoConfirmOcr: val }));
      }
    } catch (err) {
      console.error('Error updating settings:', err);
    }
  };

  // Generate Sample handwritten slip test
  const handleGenerateSampleSlip = async () => {
    setIsGeneratingSample(true);
    try {
      const res = await fetch('/api/documents/generate-sample', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: selectedCityName || 'QUEIMADOS',
          destination: 'EXTREMA',
          differential: 'CPL'
        })
      });
      if (res.ok) {
        await fetchData();
        // Switch to review or table
        setIsReviewModalOpen(true);
      }
    } catch (err) {
      console.error('Error generating sample:', err);
    } finally {
      setIsGeneratingSample(false);
    }
  };

  const allCityNames = cities.filter(c => c.active).map(c => c.name);

  return (
    <div className="flex flex-col h-screen w-screen bg-neutral-950 text-neutral-100 font-sans overflow-hidden select-none">
      {/* 1. TOP BRANDING & WORKSPACE BAR */}
      <header className="h-14 bg-neutral-950 border-b border-neutral-800 px-4 flex items-center justify-between shrink-0 z-30">
        <div className="flex items-center gap-4">
          <Logo size="md" />
          <div className="hidden lg:flex items-center gap-2 pl-4 border-l border-neutral-800 text-xs">
            <span className="font-bold text-white uppercase tracking-wider">
              SISTEMA DE GESTÃO DE ROTAS & OCR INTELIGENTE
            </span>
            <span className="text-neutral-500 font-mono">|</span>
            <span className="text-neutral-400">1.600 Folhas Manuscritas</span>
          </div>
        </div>

        {/* Top Actions & Layout Toggles */}
        <div className="flex items-center gap-2">
          {/* Layout Mode Toggles when on INICIO tab */}
          {activeTab === 'INICIO' && (
            <div className="hidden md:flex items-center gap-1 bg-neutral-900 p-1 rounded border border-neutral-800 text-xs mr-2">
              <button
                onClick={() => setViewMode('SPLIT')}
                title="Visão Dividida (Capa + Planilha da Cidade)"
                className={`p-1.5 rounded transition-colors ${
                  viewMode === 'SPLIT' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Columns className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('TABLE_ONLY')}
                title="Expandir Planilha em Tela Cheia"
                className={`p-1.5 rounded transition-colors ${
                  viewMode === 'TABLE_ONLY' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-bold transition-all shadow-md shrink-0"
          >
            <FileUp className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Importar PDFs</span>
          </button>

          <button
            onClick={() => setIsReviewModalOpen(true)}
            className="relative flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-800 rounded text-xs font-bold transition-all shrink-0"
          >
            <ClipboardCheck className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Conferência OCR</span>
            {stats.pendingReviews > 0 && (
              <span className="px-1.5 py-0.2 bg-amber-500 text-neutral-950 text-[10px] font-black rounded-full">
                {stats.pendingReviews}
              </span>
            )}
          </button>

          <button
            onClick={() => setIsExportModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition-all shadow-md shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Exportar Excel</span>
          </button>

          <button
            onClick={fetchData}
            title="Atualizar dados do servidor"
            className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-red-500' : ''}`} />
          </button>
        </div>
      </header>

      {/* 2. EXCEL TAB BAR MATCHING REFERENCE SCREENSHOT */}
      <ExcelTabBar
        cities={cities}
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onAddCity={() => setIsCitiesModalOpen(true)}
        pendingReviewsCount={stats.pendingReviews}
        onOpenExport={() => setIsExportModalOpen(true)}
      />

      {/* 3. MAIN WORKSPACE VIEW */}
      <main className="flex-1 overflow-hidden relative">
        {activeTab === 'INICIO' ? (
          viewMode === 'SPLIT' ? (
            /* Split View matching Painel_de_Rotas_Monfredini_Transportes_4e1a4e1a.png */
            <div className="grid grid-cols-1 lg:grid-cols-12 h-full w-full overflow-hidden">
              {/* Left Column: Cover Dashboard (5 cols on lg) */}
              <div className="lg:col-span-5 h-full overflow-hidden">
                <CoverDashboard
                  stats={stats}
                  cities={cities}
                  selectedCityName={selectedCityName}
                  onSelectCity={handleSelectCityFromCover}
                  onOpenImport={() => setIsImportModalOpen(true)}
                  onOpenReview={() => setIsReviewModalOpen(true)}
                  onOpenExport={() => setIsExportModalOpen(true)}
                  onOpenCities={() => setIsCitiesModalOpen(true)}
                  onGenerateSampleSlip={handleGenerateSampleSlip}
                  isGeneratingSample={isGeneratingSample}
                />
              </div>

              {/* Right Column: Active City Route Table (7 cols on lg) */}
              <div className="lg:col-span-7 h-full overflow-hidden flex flex-col">
                <RouteTable
                  currentCityName={selectedCityName}
                  routes={routes}
                  allCities={allCityNames}
                  onSelectCity={handleSelectCityInTable}
                  onGoHome={handleGoHome}
                  onEditRecord={handleOpenEditRecord}
                  onDeleteRecord={handleDeleteRecord}
                  onAddNewRoute={handleOpenAddRecord}
                  onExportCityExcel={city => {
                    setSelectedCityName(city);
                    setIsExportModalOpen(true);
                  }}
                />
              </div>
            </div>
          ) : viewMode === 'COVER_ONLY' ? (
            /* Cover Only */
            <div className="h-full w-full max-w-4xl mx-auto overflow-hidden">
              <CoverDashboard
                stats={stats}
                cities={cities}
                selectedCityName={selectedCityName}
                onSelectCity={handleSelectCityFromCover}
                onOpenImport={() => setIsImportModalOpen(true)}
                onOpenReview={() => setIsReviewModalOpen(true)}
                onOpenExport={() => setIsExportModalOpen(true)}
                onOpenCities={() => setIsCitiesModalOpen(true)}
                onGenerateSampleSlip={handleGenerateSampleSlip}
                isGeneratingSample={isGeneratingSample}
              />
            </div>
          ) : (
            /* Table Only */
            <RouteTable
              currentCityName={selectedCityName}
              routes={routes}
              allCities={allCityNames}
              onSelectCity={handleSelectCityInTable}
              onGoHome={handleGoHome}
              onEditRecord={handleOpenEditRecord}
              onDeleteRecord={handleDeleteRecord}
              onAddNewRoute={handleOpenAddRecord}
              onExportCityExcel={city => {
                setSelectedCityName(city);
                setIsExportModalOpen(true);
              }}
            />
          )
        ) : (
          /* Specific City Sheet View (Full Table with Excel feel) */
          <RouteTable
            currentCityName={activeTab}
            routes={routes}
            allCities={allCityNames}
            onSelectCity={handleSelectCityInTable}
            onGoHome={handleGoHome}
            onEditRecord={handleOpenEditRecord}
            onDeleteRecord={handleDeleteRecord}
            onAddNewRoute={handleOpenAddRecord}
            onExportCityExcel={city => {
              setSelectedCityName(city);
              setIsExportModalOpen(true);
            }}
          />
        )}
      </main>

      {/* 4. MODALS */}
      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImportComplete={async (detectedCity?: string) => {
          await fetchData();
          if (detectedCity) {
            setSelectedCityName(detectedCity);
            setActiveTab(detectedCity);
            setViewMode('TABLE_ONLY');
          }
        }}
        autoConfirm={settings.autoConfirmOcr}
        onToggleAutoConfirm={handleToggleAutoConfirm}
      />

      <ReviewModal
        isOpen={isReviewModalOpen}
        onClose={() => setIsReviewModalOpen(false)}
        records={routes}
        onUpdateRecord={(id, updates) => handleSaveRecord({ id, ...updates })}
        onDeleteRecord={handleDeleteRecord}
        onBatchApprove={handleBatchApprove}
      />

      <CitiesManager
        isOpen={isCitiesModalOpen}
        onClose={() => setIsCitiesModalOpen(false)}
        cities={cities}
        onAddCity={handleAddCity}
        onUpdateCity={handleUpdateCity}
        onDeleteCity={handleDeleteCity}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        cities={cities}
        currentCityName={selectedCityName}
      />

      <EditRouteModal
        isOpen={isEditRouteModalOpen}
        onClose={() => setIsEditRouteModalOpen(false)}
        recordToEdit={editingRecord}
        defaultOriginCity={selectedCityName}
        cities={cities}
        onSave={handleSaveRecord}
      />
    </div>
  );
}
