import React from 'react';
import { Home, Plus, FileUp, ClipboardCheck, Building2, Download } from 'lucide-react';
import { City } from '../types.js';

interface ExcelTabBarProps {
  cities: City[];
  activeTab: string; // 'INICIO', city.name, 'IMPORT', 'REVIEW', 'CITIES'
  onSelectTab: (tab: string) => void;
  onAddCity: () => void;
  pendingReviewsCount?: number;
  onOpenExport: () => void;
}

export const ExcelTabBar: React.FC<ExcelTabBarProps> = ({
  cities,
  activeTab,
  onSelectTab,
  onAddCity,
  pendingReviewsCount = 0,
  onOpenExport
}) => {
  return (
    <div className="bg-[#121824] border-b border-neutral-800 text-xs select-none">
      <div className="flex items-center justify-between overflow-x-auto no-scrollbar px-2 pt-1 gap-1">
        {/* Navigation Tabs List */}
        <div className="flex items-center gap-1 shrink-0 overflow-x-auto py-0.5">
          {/* Home Icon Tab */}
          <button
            onClick={() => onSelectTab('INICIO')}
            title="Ir para a Capa / Dashboard"
            className={`flex items-center justify-center px-3 py-1.5 font-bold transition-all border-t-2 ${
              activeTab === 'INICIO'
                ? 'bg-neutral-900 text-white border-red-500 shadow-sm'
                : 'text-neutral-400 hover:text-white border-transparent hover:bg-neutral-800/60'
            }`}
          >
            <Home className="w-3.5 h-3.5 mr-1 text-red-500" />
            <span>INÍCIO</span>
          </button>

          {/* Cities Tabs */}
          {cities
            .filter(c => c.active)
            .map(city => {
              const isActive = activeTab === city.name;
              return (
                <button
                  key={city.id}
                  onClick={() => onSelectTab(city.name)}
                  className={`flex items-center px-3.5 py-1.5 font-semibold uppercase tracking-wider transition-all border-t-2 whitespace-nowrap text-[11px] ${
                    isActive
                      ? 'bg-white text-neutral-950 border-red-600 shadow-sm font-bold'
                      : 'text-neutral-300 hover:text-white border-transparent hover:bg-neutral-800/70'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${isActive ? 'bg-red-600' : 'bg-transparent'}`} />
                  {city.name}
                </button>
              );
            })}

          {/* Add City Tab (+) */}
          <button
            onClick={onAddCity}
            title="Cadastrar Nova Cidade ou Código"
            className="flex items-center justify-center px-2 py-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800/80 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Action Controls on the Right */}
        <div className="flex items-center gap-1 shrink-0 pl-3">
          <button
            onClick={() => onSelectTab('IMPORT')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-all ${
              activeTab === 'IMPORT'
                ? 'bg-red-600 text-white'
                : 'bg-neutral-800/80 text-neutral-200 hover:bg-neutral-700 hover:text-white'
            }`}
          >
            <FileUp className="w-3.5 h-3.5 text-red-400" />
            <span>IMPORTAR PDFs</span>
          </button>

          <button
            onClick={() => onSelectTab('REVIEW')}
            className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-all ${
              activeTab === 'REVIEW'
                ? 'bg-red-600 text-white'
                : 'bg-neutral-800/80 text-neutral-200 hover:bg-neutral-700 hover:text-white'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>REVISÃO OCR</span>
            {pendingReviewsCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 bg-amber-500 text-neutral-950 text-[10px] font-black rounded-full">
                {pendingReviewsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onSelectTab('CITIES')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-all ${
              activeTab === 'CITIES'
                ? 'bg-red-600 text-white'
                : 'bg-neutral-800/80 text-neutral-200 hover:bg-neutral-700 hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">CIDADES & CÓDIGOS</span>
          </button>

          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/90 hover:bg-emerald-600 text-white rounded text-xs font-bold transition-all shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>EXPORTAR EXCEL</span>
          </button>
        </div>
      </div>
    </div>
  );
};
