import React, { useState, useMemo } from 'react';
import { RouteRecord } from '../types.js';
import {
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  Download,
  AlertCircle,
  CheckCircle2,
  ArrowUpDown,
  Home
} from 'lucide-react';

interface RouteTableProps {
  currentCityName: string;
  routes: RouteRecord[];
  allCities: string[];
  onSelectCity: (cityName: string) => void;
  onGoHome: () => void;
  onEditRecord: (record: RouteRecord) => void;
  onDeleteRecord: (id: string) => void;
  onAddNewRoute: (originCity: string) => void;
  onExportCityExcel: (cityName: string) => void;
}

export const RouteTable: React.FC<RouteTableProps> = ({
  currentCityName,
  routes,
  allCities,
  onSelectCity,
  onGoHome,
  onEditRecord,
  onDeleteRecord,
  onAddNewRoute,
  onExportCityExcel
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [differentialFilter, setDifferentialFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'type' | 'value' | 'destination'>('destination');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Filter routes belonging to this origin city
  const cityRoutes = useMemo(() => {
    return routes.filter(r => r.originCity.toUpperCase() === currentCityName.toUpperCase());
  }, [routes, currentCityName]);

  // Apply search & differential filter
  const filteredRoutes = useMemo(() => {
    let list = [...cityRoutes];

    if (differentialFilter !== 'ALL') {
      if (differentialFilter === 'NORMAL') {
        list = list.filter(r => r.differential === 'NORMAL' || r.differential === '-');
      } else {
        list = list.filter(r => r.differential === differentialFilter);
      }
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(r =>
        r.destinationCity.toLowerCase().includes(q) ||
        r.destinationCode.toLowerCase().includes(q) ||
        r.vehicleType.toLowerCase().includes(q) ||
        r.client.toLowerCase().includes(q) ||
        r.totalValue.toLowerCase().includes(q)
      );
    }

    return list;
  }, [cityRoutes, differentialFilter, searchQuery]);

  // Group routes by Destination + Destination Code + Differential
  const groupedSections = useMemo(() => {
    const groups: {
      key: string;
      title: string;
      destination: string;
      destinationCode: string;
      differential: string;
      records: RouteRecord[];
    }[] = [];

    const map = new Map<string, RouteRecord[]>();

    for (const rec of filteredRoutes) {
      const key = `${rec.destinationCity}__${rec.destinationCode}__${rec.differential}`;
      if (!map.has(key)) {
        map.set(key, []);
      }
      map.get(key)!.push(rec);
    }

    // Convert map to sorted list
    for (const [key, records] of map.entries()) {
      if (records.length === 0) continue;
      const first = records[0];
      const diffLabel = first.differential && first.differential !== 'NORMAL' && first.differential !== '-'
        ? ` (${first.differential})`
        : '';
      const title = `${first.originCity} → ${first.destinationCity}${diffLabel} | CÓDIGO DESTINO: ${first.destinationCode}`;

      // Sort records within group by default standard vehicle hierarchy or sort criteria
      records.sort((a, b) => {
        if (sortBy === 'value') {
          const valA = a.numericValue || 0;
          const valB = b.numericValue || 0;
          return sortOrder === 'asc' ? valA - valB : valB - valA;
        }
        return 0;
      });

      groups.push({
        key,
        title,
        destination: first.destinationCity,
        destinationCode: first.destinationCode,
        differential: first.differential,
        records
      });
    }

    // Sort groups
    groups.sort((a, b) => a.destination.localeCompare(b.destination));

    return groups;
  }, [filteredRoutes, sortBy, sortOrder]);

  return (
    <div className="flex flex-col w-full h-full bg-neutral-900 text-neutral-100 overflow-y-auto">
      {/* Top Bar matching Excel Screenshot: "⌂ VOLTAR À CAPA" */}
      <div className="bg-[#0B192C] text-white px-4 py-2 border-b border-neutral-800 flex items-center justify-between shadow-sm sticky top-0 z-20">
        <button
          onClick={onGoHome}
          className="flex items-center gap-2 text-xs font-bold hover:text-red-400 transition-colors uppercase tracking-wider"
        >
          <Home className="w-3.5 h-3.5 text-red-500" />
          <span>⌂ VOLTAR À CAPA</span>
        </button>

        <div className="flex items-center gap-3">
          <span className="text-[11px] text-neutral-400 hidden sm:inline">
            Visualizando planilha de rotas de: <strong className="text-white">{currentCityName}</strong>
          </span>
          <button
            onClick={() => onExportCityExcel(currentCityName)}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold transition-all shadow-sm"
          >
            <Download className="w-3 h-3" />
            <span>Exportar Esta Cidade (.xlsx)</span>
          </button>
        </div>
      </div>

      {/* City Hero Header Banner */}
      <div className="relative bg-gradient-to-r from-neutral-950 via-neutral-900 to-neutral-950 border-b border-neutral-800 px-6 py-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-7 bg-red-600 rounded-sm" />
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white uppercase font-sans">
                {currentCityName}
              </h1>
            </div>
            <p className="text-xs text-neutral-400 tracking-wider uppercase font-semibold mt-1 pl-4">
              ROTAS DISPONÍVEIS & COTAÇÕES ATIVAS
            </p>
          </div>

          {/* Quick city selector dropdown + new route button */}
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="flex flex-col text-right">
              <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-wider">
                SELECIONE A CIDADE
              </span>
              <select
                value={currentCityName}
                onChange={e => onSelectCity(e.target.value)}
                aria-label="Selecionar cidade de origem"
                className="bg-neutral-800 border border-neutral-700 text-white text-xs font-bold rounded px-3 py-1.5 focus:outline-none focus:border-red-500 uppercase cursor-pointer"
              >
                {allCities.map(city => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => onAddNewRoute(currentCityName)}
              className="mt-3 sm:mt-0 flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-bold transition-all shadow-md shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Nova Rota</span>
            </button>
          </div>
        </div>

        {/* Filters and search bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-neutral-800/80">
          <div className="flex items-center gap-2 flex-1 min-w-[240px] max-w-md">
            <div className="relative w-full">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="text"
                placeholder="Filtrar por destino, código, veículo ou cliente..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-700 rounded pl-9 pr-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded border border-neutral-800 text-[11px]">
              <span className="text-neutral-400 px-1 font-semibold flex items-center gap-1">
                <Filter className="w-3 h-3 text-red-500" />
                Diferencial:
              </span>
              {['ALL', 'NORMAL', 'CPL', 'CIRCUITO'].map(diff => (
                <button
                  key={diff}
                  onClick={() => setDifferentialFilter(diff)}
                  className={`px-2 py-0.5 rounded font-bold transition-colors ${
                    differentialFilter === diff
                      ? 'bg-red-600 text-white'
                      : 'text-neutral-300 hover:text-white hover:bg-neutral-800'
                  }`}
                >
                  {diff === 'ALL' ? 'Todos' : diff}
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                setSortBy('value');
                setSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
              }}
              className="flex items-center gap-1 px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 rounded text-neutral-200 text-xs font-semibold"
              title="Alternar ordenação por valor"
            >
              <ArrowUpDown className="w-3 h-3" />
              <span>Ordenar Valor ({sortOrder === 'asc' ? 'Menor' : 'Maior'})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Table Content: Grouped Sections matching Excel Reference */}
      <div className="p-4 sm:p-6 space-y-8 max-w-7xl mx-auto w-full">
        {groupedSections.length === 0 ? (
          <div className="p-12 text-center bg-neutral-900 rounded-lg border border-neutral-800">
            <AlertCircle className="w-10 h-10 text-neutral-500 mx-auto mb-3" />
            <h3 className="text-base font-bold text-white mb-1">Nenhuma rota encontrada para esta cidade</h3>
            <p className="text-xs text-neutral-400 max-w-md mx-auto mb-4">
              Não encontramos rotas cadastradas com os filtros atuais. Importe documentos PDF com OCR ou adicione
              manualmente uma nova rota.
            </p>
            <button
              onClick={() => onAddNewRoute(currentCityName)}
              className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded transition-all shadow"
            >
              Adicionar Primeira Rota
            </button>
          </div>
        ) : (
          groupedSections.map(section => (
            <div
              key={section.key}
              className="rounded overflow-hidden border border-neutral-700/80 shadow-xl bg-white"
            >
              {/* Vibrant Red Banner Header */}
              <div className="bg-[#B91C1C] text-white px-4 py-2.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-4 bg-white rounded-full opacity-80" />
                  <h2 className="text-sm sm:text-base font-black tracking-wide uppercase font-sans">
                    {section.title}
                  </h2>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="px-2 py-0.5 bg-black/30 rounded text-[11px] font-mono tracking-wider">
                    {section.records.length} VEÍCULOS
                  </span>
                </div>
              </div>

              {/* 8-Column Data Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-neutral-900 text-center border-collapse">
                  <thead>
                    <tr className="bg-[#0C1E30] text-white font-bold uppercase text-[11px] tracking-wider select-none border-b border-neutral-800">
                      <th className="py-2.5 px-3 text-left">CLIENTE</th>
                      <th className="py-2.5 px-3">CIDADE ORIGEM</th>
                      <th className="py-2.5 px-3">SIGLA ORIGEM</th>
                      <th className="py-2.5 px-3">CIDADE DESTINO</th>
                      <th className="py-2.5 px-3">SIGLA DESTINO</th>
                      <th className="py-2.5 px-3">TIPO</th>
                      <th className="py-2.5 px-3 text-right">VALOR</th>
                      <th className="py-2.5 px-3">DIFERENCIAL</th>
                      <th className="py-2.5 px-3 text-center">AÇÕES</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-200">
                    {section.records.map((rec, index) => {
                      const isEven = index % 2 === 1;
                      const hasValue = rec.totalValue !== '-';
                      const isReviewNeeded = rec.reviewStatus === 'AGUARDANDO CONFERÊNCIA';

                      return (
                        <tr
                          key={rec.id}
                          className={`transition-colors hover:bg-red-50/70 ${
                            isEven ? 'bg-[#F8F9FA]' : 'bg-white'
                          } ${isReviewNeeded ? 'border-l-4 border-l-amber-500' : ''}`}
                        >
                          <td className="py-2 px-3 text-left font-medium text-neutral-800 whitespace-nowrap">
                            {rec.client}
                          </td>
                          <td className="py-2 px-3 font-semibold text-neutral-900 whitespace-nowrap">
                            {rec.originCity}
                          </td>
                          <td className="py-2 px-3 font-mono text-neutral-600 font-bold text-[11px]">
                            {rec.originCode}
                          </td>
                          <td className="py-2 px-3 font-semibold text-neutral-900 whitespace-nowrap">
                            {rec.destinationCity}
                          </td>
                          <td className="py-2 px-3 font-mono text-neutral-700 font-bold text-[11px]">
                            <span className="px-1.5 py-0.5 bg-neutral-200 rounded text-neutral-800">
                              {rec.destinationCode}
                            </span>
                          </td>
                          <td className="py-2 px-3 font-bold text-neutral-900 whitespace-nowrap text-left sm:text-center">
                            {rec.vehicleType}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-black tabular-nums text-xs whitespace-nowrap">
                            <span
                              className={`px-1.5 py-0.5 rounded ${
                                hasValue
                                  ? 'text-neutral-950 font-extrabold bg-neutral-100'
                                  : 'text-neutral-400 font-normal'
                              }`}
                            >
                              {rec.totalValue}
                            </span>
                          </td>
                          <td className="py-2 px-3 whitespace-nowrap font-semibold">
                            <span
                              className={`inline-block px-2 py-0.5 text-[10px] rounded font-bold uppercase tracking-wider ${
                                rec.differential === 'CPL'
                                  ? 'bg-red-100 text-red-700 border border-red-300'
                                  : rec.differential === 'CIRCUITO'
                                  ? 'bg-purple-100 text-purple-700 border border-purple-300'
                                  : rec.differential === 'NORMAL'
                                  ? 'bg-emerald-50 text-emerald-800'
                                  : 'text-neutral-400'
                              }`}
                            >
                              {rec.differential === 'NORMAL' ? 'Normal' : rec.differential}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center gap-1.5">
                              {isReviewNeeded && (
                                <span
                                  title="Aguardando conferência do OCR"
                                  className="text-amber-600"
                                >
                                  <AlertCircle className="w-3.5 h-3.5" />
                                </span>
                              )}
                              <button
                                onClick={() => onEditRecord(rec)}
                                title="Editar registro"
                                className="p-1 text-neutral-500 hover:text-neutral-950 hover:bg-neutral-200 rounded transition-colors"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => onDeleteRecord(rec.id)}
                                title="Excluir registro"
                                className="p-1 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
