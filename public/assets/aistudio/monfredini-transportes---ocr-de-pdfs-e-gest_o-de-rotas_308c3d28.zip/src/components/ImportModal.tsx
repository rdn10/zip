import React, { useState, useRef, useEffect } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle,
  AlertCircle,
  X,
  RefreshCw,
  Clock,
  Sparkles,
  Settings2,
  Trash2,
  Eye
} from 'lucide-react';
import { UploadedDocument } from '../types.js';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete: (detectedCity?: string) => void;
  autoConfirm: boolean;
  onToggleAutoConfirm: (val: boolean) => void;
}

interface QueuedFile {
  id: string;
  file: File;
  name: string;
  size: number;
  progress: number;
  status: 'PENDING' | 'UPLOADING' | 'PROCESSING_OCR' | 'COMPLETED' | 'DUPLICATE' | 'ERROR';
  recordsCount?: number;
  originCity?: string;
  errorMessage?: string;
}

export const ImportModal: React.FC<ImportModalProps> = ({
  isOpen,
  onClose,
  onImportComplete,
  autoConfirm,
  onToggleAutoConfirm
}) => {
  const [queuedFiles, setQueuedFiles] = useState<QueuedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessingQueue, setIsProcessingQueue] = useState(false);
  const [lastImportedCity, setLastImportedCity] = useState<string | null>(null);
  const [documentHistory, setDocumentHistory] = useState<UploadedDocument[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch document history on open
  useEffect(() => {
    if (isOpen) {
      loadHistory();
    }
  }, [isOpen]);

  const loadHistory = async () => {
    setIsLoadingHistory(true);
    try {
      const res = await fetch('/api/documents');
      if (res.ok) {
        const data = await res.json();
        setDocumentHistory(data);
      }
    } catch (err) {
      console.error('Error loading documents history:', err);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const handleFilesAdded = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const newItems: QueuedFile[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf') || file.type.startsWith('image/')) {
        newItems.push({
          id: `queue-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 7)}`,
          file,
          name: file.name,
          size: file.size,
          progress: 0,
          status: 'PENDING'
        });
      }
    }

    setQueuedFiles(prev => [...prev, ...newItems]);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFilesAdded(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const cancelProcessing = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsProcessingQueue(false);
    setQueuedFiles(prev =>
      prev.map(f => (f.status === 'UPLOADING' || f.status === 'PROCESSING_OCR' ? { ...f, status: 'PENDING', progress: 0 } : f))
    );
  };

  const processQueue = async () => {
    if (queuedFiles.length === 0) return;
    setIsProcessingQueue(true);
    abortControllerRef.current = new AbortController();

    const pending = queuedFiles.filter(f => f.status === 'PENDING');

    for (const item of pending) {
      try {
        // Step 1: Uploading
        setQueuedFiles(prev =>
          prev.map(f => (f.id === item.id ? { ...f, status: 'UPLOADING', progress: 30 } : f))
        );

        const formData = new FormData();
        formData.append('files', item.file);

        // Step 2: OCR Processing with Gemini
        setQueuedFiles(prev =>
          prev.map(f => (f.id === item.id ? { ...f, status: 'PROCESSING_OCR', progress: 65 } : f))
        );

        const res = await fetch('/api/documents/upload', {
          method: 'POST',
          body: formData,
          signal: abortControllerRef.current.signal
        });

        if (!res.ok) {
          throw new Error(`Falha no upload (${res.statusText})`);
        }

        const data = await res.json();
        const result = data.results?.[0];

        if (result?.status === 'DUPLICATE') {
          setQueuedFiles(prev =>
            prev.map(f =>
              f.id === item.id
                ? {
                    ...f,
                    status: 'DUPLICATE',
                    progress: 100,
                    errorMessage: 'Arquivo idêntico já cadastrado no sistema (evitou duplicação).'
                  }
                : f
            )
          );
        } else if (result?.status === 'ERROR') {
          setQueuedFiles(prev =>
            prev.map(f =>
              f.id === item.id
                ? { ...f, status: 'ERROR', progress: 100, errorMessage: result.error || 'Erro no OCR' }
                : f
            )
          );
        } else {
          const detectedCity = result?.originCity || 'RIO DE JANEIRO';
          setLastImportedCity(detectedCity);
          setQueuedFiles(prev =>
            prev.map(f =>
              f.id === item.id
                ? {
                    ...f,
                    status: 'COMPLETED',
                    progress: 100,
                    originCity: detectedCity,
                    recordsCount: result?.recordsExtracted || 0
                  }
                : f
            )
          );
        }
      } catch (err: any) {
        if (err.name === 'AbortError') {
          break;
        }
        setQueuedFiles(prev =>
          prev.map(f =>
            f.id === item.id ? { ...f, status: 'ERROR', progress: 100, errorMessage: err.message } : f
          )
        );
      }
    }

    setIsProcessingQueue(false);
    await loadHistory();
    // Notify parent with last imported city if available
    const lastCity = queuedFiles.find(f => f.originCity)?.originCity || 'RIO DE JANEIRO';
    onImportComplete(lastCity);
  };

  const handleGenerateSampleSlip = async () => {
    setIsGeneratingSample(true);
    try {
      const res = await fetch('/api/documents/generate-sample', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: 'QUEIMADOS',
          destination: 'EXTREMA',
          differential: 'CPL'
        })
      });
      if (res.ok) {
        const data = await res.json();
        await loadHistory();
        onImportComplete();
      }
    } catch (err) {
      console.error('Error generating sample:', err);
    } finally {
      setIsGeneratingSample(false);
    }
  };

  const handleReprocess = async (docId: string) => {
    try {
      const res = await fetch(`/api/documents/${docId}/reprocess`, { method: 'POST' });
      if (res.ok) {
        await loadHistory();
        onImportComplete();
      }
    } catch (err) {
      console.error('Error reprocessing:', err);
    }
  };

  // Overall progress calculation
  const totalFiles = queuedFiles.length;
  const completedCount = queuedFiles.filter(f => f.status === 'COMPLETED' || f.status === 'DUPLICATE').length;
  const overallProgress = totalFiles > 0
    ? Math.round(queuedFiles.reduce((acc, f) => acc + f.progress, 0) / totalFiles)
    : 0;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl flex flex-col overflow-hidden text-neutral-100">
        {/* Header */}
        <div className="px-6 py-4 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-600/20 text-red-500 rounded-lg">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white uppercase tracking-wide">
                IMPORTAR DOCUMENTOS & OCR DE FRETES
              </h2>
              <p className="text-xs text-neutral-400">
                Processamento contínuo e cumulativo com IA Gemini 3.8 Flash
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Auto confirm toggle */}
            <label className="flex items-center gap-2 cursor-pointer bg-neutral-800/80 px-3 py-1.5 rounded text-xs select-none border border-neutral-700">
              <input
                type="checkbox"
                checked={autoConfirm}
                onChange={e => onToggleAutoConfirm(e.target.checked)}
                className="rounded accent-red-600"
              />
              <span className="text-neutral-300 font-medium">Aprovação Automática</span>
            </label>

            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Drag & Drop Area */}
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${
              isDragging
                ? 'border-red-500 bg-red-500/10'
                : 'border-neutral-700 hover:border-neutral-500 bg-neutral-950/40'
            }`}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={e => handleFilesAdded(e.target.files)}
              multiple
              accept=".pdf,application/pdf,image/*"
              className="hidden"
            />
            <UploadCloud className="w-12 h-12 text-neutral-400 mx-auto mb-3" />
            <p className="text-sm font-bold text-white mb-1">
              Arraste e solte seus arquivos PDF aqui, ou clique para selecionar
            </p>
            <p className="text-xs text-neutral-400 max-w-md mx-auto mb-4">
              Suporta múltiplos PDFs de transporte preenchidos manualmente ou digitalizados.
              O sistema preserva documentos anteriores e acumula à base centralizada.
            </p>
            <button
              type="button"
              className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded transition-all shadow"
              onClick={e => {
                e.stopPropagation();
                fileInputRef.current?.click();
              }}
            >
              Selecionar Arquivos PDF
            </button>
          </div>

          {/* Quick Demo Test Slip Generator */}
          <div className="flex items-center justify-between p-3.5 bg-neutral-950/80 border border-neutral-800 rounded-lg">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="text-xs">
                <span className="font-bold text-white">Não possui um PDF em mãos agora?</span>
                <p className="text-neutral-400 text-[11px]">
                  Gere instantaneamente uma folha manuscrita simulada e teste a extração OCR e expansão de códigos.
                </p>
              </div>
            </div>
            <button
              onClick={handleGenerateSampleSlip}
              disabled={isGeneratingSample}
              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-amber-400 border border-neutral-700 rounded text-xs font-bold transition-all shrink-0"
            >
              {isGeneratingSample ? 'Processando...' : 'Gerar & Testar PDF'}
            </button>
          </div>

          {/* Success Direct Jump Banner */}
          {lastImportedCity && (
            <div className="p-4 bg-emerald-950/80 border border-emerald-600/70 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs shadow-lg animate-in fade-in">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <p className="font-extrabold text-white text-sm">
                    Rotas importadas com sucesso!
                  </p>
                  <p className="text-emerald-300">
                    Os registros extraídos foram adicionados à planilha de <strong>{lastImportedCity}</strong>.
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  onImportComplete(lastImportedCity);
                  onClose();
                }}
                className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded shadow transition-all whitespace-nowrap text-xs"
              >
                Abrir Planilha de {lastImportedCity} →
              </button>
            </div>
          )}

          {/* Current Queue Section */}
          {queuedFiles.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
                  FILA DE ARQUIVOS ({queuedFiles.length})
                </span>
                <div className="flex items-center gap-2">
                  {isProcessingQueue ? (
                    <button
                      onClick={cancelProcessing}
                      className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-red-400 border border-red-500/30 rounded text-xs font-bold"
                    >
                      Cancelar Processamento
                    </button>
                  ) : (
                    <button
                      onClick={processQueue}
                      disabled={queuedFiles.every(f => f.status === 'COMPLETED')}
                      className="px-4 py-1.5 bg-red-600 hover:bg-red-500 disabled:bg-neutral-800 text-white font-bold text-xs rounded transition-all"
                    >
                      Iniciar Extração OCR
                    </button>
                  )}
                </div>
              </div>

              {/* Overall Progress Bar */}
              {isProcessingQueue && (
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-neutral-400 font-mono">
                    <span>Progresso Geral</span>
                    <span>{overallProgress}% ({completedCount}/{totalFiles})</span>
                  </div>
                  <div className="w-full h-2 bg-neutral-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-red-600 transition-all duration-300"
                      style={{ width: `${overallProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Queued files list */}
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {queuedFiles.map(item => (
                  <div
                    key={item.id}
                    className="p-3 bg-neutral-950 border border-neutral-800 rounded-lg flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <FileText className="w-4 h-4 text-red-500 shrink-0" />
                      <div className="truncate">
                        <p className="font-semibold text-white truncate">{item.name}</p>
                        <p className="text-[10px] text-neutral-400 font-mono">
                          {(item.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      {/* Status Badge */}
                      {item.status === 'PENDING' && (
                        <span className="text-[11px] text-neutral-400 font-medium">Pendente</span>
                      )}
                      {item.status === 'UPLOADING' && (
                        <span className="text-[11px] text-blue-400 font-medium flex items-center gap-1">
                          <RefreshCw className="w-3 h-3 animate-spin" /> Enviando...
                        </span>
                      )}
                      {item.status === 'PROCESSING_OCR' && (
                        <span className="text-[11px] text-amber-400 font-medium flex items-center gap-1">
                          <RefreshCw className="w-3 h-3 animate-spin" /> Processando OCR...
                        </span>
                      )}
                      {item.status === 'COMPLETED' && (
                        <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" /> {item.recordsCount} rotas extraídas
                        </span>
                      )}
                      {item.status === 'DUPLICATE' && (
                        <span className="text-[11px] text-amber-300 font-medium" title={item.errorMessage}>
                          Já importado
                        </span>
                      )}
                      {item.status === 'ERROR' && (
                        <span className="text-[11px] text-red-400 font-medium" title={item.errorMessage}>
                          Erro no OCR
                        </span>
                      )}

                      {!isProcessingQueue && item.status === 'PENDING' && (
                        <button
                          onClick={() => setQueuedFiles(prev => prev.filter(f => f.id !== item.id))}
                          className="p-1 text-neutral-500 hover:text-red-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Historical Documents Table */}
          <div className="space-y-3 pt-2 border-t border-neutral-800">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-neutral-400" />
                HISTÓRICO DE DOCUMENTOS IMPORTADOS ({documentHistory.length})
              </span>
              <button
                onClick={loadHistory}
                className="text-[11px] text-neutral-400 hover:text-white flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" /> Atualizar
              </button>
            </div>

            {isLoadingHistory ? (
              <div className="py-6 text-center text-xs text-neutral-500">Carregando histórico...</div>
            ) : documentHistory.length === 0 ? (
              <div className="py-6 text-center text-xs text-neutral-500 bg-neutral-950/50 rounded-lg border border-neutral-800">
                Nenhum documento importado ainda.
              </div>
            ) : (
              <div className="max-h-48 overflow-y-auto rounded-lg border border-neutral-800 bg-neutral-950 divide-y divide-neutral-800/80">
                {documentHistory.map(doc => (
                  <div
                    key={doc.id}
                    className="p-3 flex items-center justify-between text-xs hover:bg-neutral-900/60 transition-colors"
                  >
                    <div className="min-w-0 pr-3">
                      <p className="font-semibold text-white truncate">{doc.filename}</p>
                      <p className="text-[10px] text-neutral-400 font-mono">
                        Hash: {doc.fileHash.substring(0, 16)}... ·{' '}
                        {new Date(doc.uploadedAt).toLocaleDateString('pt-BR')} às{' '}
                        {new Date(doc.uploadedAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="font-mono text-neutral-300 font-bold text-[11px]">
                        {doc.totalRecordsExtracted} rotas
                      </span>

                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          doc.processingStatus === 'COMPLETED'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : doc.processingStatus === 'PROCESSING'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800'
                            : 'bg-red-950 text-red-400 border border-red-800'
                        }`}
                      >
                        {doc.processingStatus}
                      </span>

                      <button
                        onClick={() => handleReprocess(doc.id)}
                        title="Reprocessar OCR"
                        className="p-1 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
          <span>Armazenamento local seguro e centralizado em banco de dados</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded font-semibold text-xs"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
