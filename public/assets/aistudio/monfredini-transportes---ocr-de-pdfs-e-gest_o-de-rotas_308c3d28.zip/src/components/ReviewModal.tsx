import React, { useState } from 'react';
import {
  ClipboardCheck,
  Check,
  X,
  AlertCircle,
  Edit2,
  Trash2,
  CheckCheck,
  Search,
  Filter,
  FileText
} from 'lucide-react';
import { RouteRecord, ReviewStatus, Differential } from '../types.js';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: RouteRecord[];
  onUpdateRecord: (id: string, updates: Partial<RouteRecord>) => void;
  onDeleteRecord: (id: string) => void;
  onBatchApprove: (ids: string[]) => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({
  isOpen,
  onClose,
  records,
  onUpdateRecord,
  onDeleteRecord,
  onBatchApprove
}) => {
  const [selectedRecordId, setSelectedRecordId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('AGUARDANDO CONFERÊNCIA');
  const [search, setSearch] = useState('');

  // Editing state for selected record
  const [editClient, setEditClient] = useState('');
  const [editOrigin, setEditOrigin] = useState('');
  const [editOriginCode, setEditOriginCode] = useState('');
  const [editDestination, setEditDestination] = useState('');
  const [editDestinationCode, setEditDestinationCode] = useState('');
  const [editVehicleType, setEditVehicleType] = useState('');
  const [editTotalValue, setEditTotalValue] = useState('');
  const [editDifferential, setEditDifferential] = useState<Differential>('NORMAL');
  const [editStatus, setEditStatus] = useState<ReviewStatus>('REVISADO');

  // Filter records
  const filteredRecords = records.filter(r => {
    if (filterStatus !== 'ALL' && r.reviewStatus !== filterStatus) {
      return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      return (
        r.originCity.toLowerCase().includes(q) ||
        r.destinationCity.toLowerCase().includes(q) ||
        r.vehicleType.toLowerCase().includes(q) ||
        r.documentName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const selectedRecord = records.find(r => r.id === selectedRecordId) || filteredRecords[0] || null;

  // When selected record changes, sync edit form
  React.useEffect(() => {
    if (selectedRecord) {
      setSelectedRecordId(selectedRecord.id);
      setEditClient(selectedRecord.client);
      setEditOrigin(selectedRecord.originCity);
      setEditOriginCode(selectedRecord.originCode);
      setEditDestination(selectedRecord.destinationCity);
      setEditDestinationCode(selectedRecord.destinationCode);
      setEditVehicleType(selectedRecord.vehicleType);
      setEditTotalValue(selectedRecord.totalValue);
      setEditDifferential(selectedRecord.differential);
      setEditStatus(selectedRecord.reviewStatus);
    }
  }, [selectedRecord?.id]);

  const handleSaveSelected = () => {
    if (!selectedRecord) return;
    onUpdateRecord(selectedRecord.id, {
      client: editClient,
      originCity: editOrigin.toUpperCase().trim(),
      originCode: editOriginCode.toUpperCase().trim(),
      destinationCity: editDestination.toUpperCase().trim(),
      destinationCode: editDestinationCode.toUpperCase().trim(),
      vehicleType: editVehicleType,
      totalValue: editTotalValue,
      differential: editDifferential,
      reviewStatus: 'REVISADO'
    });
  };

  const handleApproveAllPending = () => {
    const pendingIds = records
      .filter(r => r.reviewStatus === 'AGUARDANDO CONFERÊNCIA')
      .map(r => r.id);
    if (pendingIds.length > 0) {
      onBatchApprove(pendingIds);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-5 bg-black/85 backdrop-blur-sm">
      <div className="relative w-full max-w-6xl h-[92vh] bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl flex flex-col overflow-hidden text-neutral-100">
        {/* Header */}
        <div className="px-6 py-4 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white uppercase tracking-wide">
                CONFERÊNCIA E REVISÃO DE OCR
              </h2>
              <p className="text-xs text-neutral-400">
                Auditoria de confiança, valores manuscritos e confirmação de rotas
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleApproveAllPending}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition-all shadow"
            >
              <CheckCheck className="w-4 h-4" />
              <span>Aprovar Todos Pendentes</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filters and search strip */}
        <div className="px-6 py-3 bg-neutral-900/90 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-neutral-400 font-medium">Filtrar Status:</span>
            {['ALL', 'AGUARDANDO CONFERÊNCIA', 'REVISADO', 'PROCESSADO'].map(st => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-2.5 py-1 rounded font-bold transition-colors ${
                  filterStatus === st
                    ? 'bg-red-600 text-white'
                    : 'bg-neutral-800 text-neutral-300 hover:text-white'
                }`}
              >
                {st === 'ALL' ? 'Todos' : st}
              </button>
            ))}
          </div>

          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              placeholder="Buscar registro..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-700 rounded pl-9 pr-3 py-1 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
            />
          </div>
        </div>

        {/* 2-Column Split: Left = List of records, Right = Details & Correction */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          {/* Left Column: Records list */}
          <div className="md:col-span-6 border-r border-neutral-800 overflow-y-auto divide-y divide-neutral-800/80 bg-neutral-950/40">
            {filteredRecords.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-500">
                Nenhum registro encontrado para este filtro.
              </div>
            ) : (
              filteredRecords.map(rec => {
                const isSelected = selectedRecord?.id === rec.id;
                const isPending = rec.reviewStatus === 'AGUARDANDO CONFERÊNCIA';

                return (
                  <div
                    key={rec.id}
                    onClick={() => setSelectedRecordId(rec.id)}
                    className={`p-3.5 cursor-pointer transition-colors flex items-start justify-between gap-3 text-xs ${
                      isSelected
                        ? 'bg-neutral-800/90 border-l-4 border-l-red-600'
                        : isPending
                        ? 'hover:bg-neutral-900 border-l-4 border-l-amber-500'
                        : 'hover:bg-neutral-900/60'
                    }`}
                  >
                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-white uppercase">
                          {rec.originCity} → {rec.destinationCity}
                        </span>
                        <span className="px-1.5 py-0.2 bg-neutral-800 text-neutral-300 font-mono text-[10px] rounded font-bold">
                          {rec.destinationCode}
                        </span>
                        {rec.differential !== 'NORMAL' && rec.differential !== '-' && (
                          <span className="px-1.5 py-0.2 bg-red-950 text-red-400 border border-red-800 text-[10px] rounded font-bold">
                            {rec.differential}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-3 text-[11px] text-neutral-400">
                        <span className="font-semibold text-neutral-200">{rec.vehicleType}</span>
                        <span>·</span>
                        <span className="font-mono text-white font-bold">{rec.totalValue}</span>
                      </div>

                      <p className="text-[10px] text-neutral-400 truncate flex items-center gap-1">
                        <FileText className="w-3 h-3 text-neutral-400" />
                        {rec.documentName} (Pág. {rec.pageNumber})
                      </p>
                    </div>

                    <div className="flex flex-col items-end gap-1.5 shrink-0">
                      {/* Confidence Meter */}
                      <span
                        className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          rec.ocrConfidence >= 90
                            ? 'bg-emerald-950 text-emerald-400'
                            : rec.ocrConfidence >= 80
                            ? 'bg-amber-950 text-amber-400'
                            : 'bg-red-950 text-red-400'
                        }`}
                      >
                        {rec.ocrConfidence}% OCR
                      </span>

                      <span
                        className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                          rec.reviewStatus === 'REVISADO'
                            ? 'bg-emerald-900/60 text-emerald-300'
                            : rec.reviewStatus === 'AGUARDANDO CONFERÊNCIA'
                            ? 'bg-amber-900/60 text-amber-300'
                            : 'bg-neutral-800 text-neutral-300'
                        }`}
                      >
                        {rec.reviewStatus}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Right Column: Record Detail & Direct Correction Form */}
          <div className="md:col-span-6 p-6 overflow-y-auto space-y-5 bg-neutral-900">
            {selectedRecord ? (
              <>
                <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider">
                      DETALHES DO REGISTRO
                    </span>
                    <h3 className="text-base font-black text-white">
                      {selectedRecord.originCity} → {selectedRecord.destinationCity}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onDeleteRecord(selectedRecord.id)}
                      className="p-1.5 text-neutral-400 hover:text-red-400 hover:bg-neutral-800 rounded transition-colors"
                      title="Excluir este registro"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Document context banner */}
                <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-lg flex items-center justify-between text-xs">
                  <div>
                    <span className="text-neutral-400 text-[11px]">Documento de Origem:</span>
                    <p className="font-semibold text-white">{selectedRecord.documentName}</p>
                    <p className="text-[10px] text-neutral-500 font-mono">Página {selectedRecord.pageNumber}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-neutral-400">Grau de Confiança OCR</span>
                    <p className="text-base font-bold text-emerald-400 font-mono">{selectedRecord.ocrConfidence}%</p>
                  </div>
                </div>

                {/* Edit Form */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="col-span-2">
                    <label className="block text-neutral-400 font-medium mb-1">Cliente</label>
                    <input
                      type="text"
                      value={editClient}
                      onChange={e => setEditClient(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-medium focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-400 font-medium mb-1">Cidade Origem</label>
                    <input
                      type="text"
                      value={editOrigin}
                      onChange={e => setEditOrigin(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-bold uppercase focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-400 font-medium mb-1">Sigla Origem</label>
                    <input
                      type="text"
                      value={editOriginCode}
                      onChange={e => setEditOriginCode(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-mono font-bold uppercase focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-400 font-medium mb-1">Cidade Destino</label>
                    <input
                      type="text"
                      value={editDestination}
                      onChange={e => setEditDestination(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-bold uppercase focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-400 font-medium mb-1">Sigla Destino</label>
                    <input
                      type="text"
                      value={editDestinationCode}
                      onChange={e => setEditDestinationCode(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-mono font-bold uppercase focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-neutral-400 font-medium mb-1">
                      Perfil de Veículo (Tipo)
                    </label>
                    <input
                      type="text"
                      value={editVehicleType}
                      onChange={e => setEditVehicleType(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-bold focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-400 font-medium mb-1">Valor Total (R$)</label>
                    <input
                      type="text"
                      value={editTotalValue}
                      onChange={e => setEditTotalValue(e.target.value)}
                      placeholder="R$ 1.000,00 ou -"
                      className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-mono font-extrabold focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-400 font-medium mb-1">Diferencial</label>
                    <select
                      value={editDifferential}
                      onChange={e => setEditDifferential(e.target.value as Differential)}
                      className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-bold focus:outline-none focus:border-red-500 cursor-pointer"
                    >
                      <option value="NORMAL">NORMAL</option>
                      <option value="CPL">CPL</option>
                      <option value="CIRCUITO">CIRCUITO</option>
                      <option value="-">-</option>
                    </select>
                  </div>
                </div>

                {/* Save and confirm actions */}
                <div className="pt-4 border-t border-neutral-800 flex items-center justify-end gap-3">
                  <button
                    onClick={handleSaveSelected}
                    className="flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded font-bold text-xs transition-all shadow-md"
                  >
                    <Check className="w-4 h-4" />
                    <span>Salvar e Marcar como Revisado</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-neutral-500">
                Selecione um registro na lista ao lado para inspecionar e revisar.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
