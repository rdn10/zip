import React, { useState, useEffect } from 'react';
import { RouteRecord, Differential, ReviewStatus, City } from '../types.js';
import { X, Check, Plus, Edit } from 'lucide-react';

interface EditRouteModalProps {
  isOpen: boolean;
  onClose: () => void;
  recordToEdit: RouteRecord | null;
  defaultOriginCity?: string;
  cities: City[];
  onSave: (record: Partial<RouteRecord> & { id?: string }) => void;
}

const VEHICLE_OPTIONS = [
  'BITREM',
  'BITREM 3º',
  'CARRETA CASA',
  'TRUCK CASA',
  'CARRETA AGREGADO',
  'CARRETA 3º',
  'TRUCK 3º',
  'TOCO 3º',
  'MÉDIO (3/4 - 3º)',
  'VUC 3º'
];

export const EditRouteModal: React.FC<EditRouteModalProps> = ({
  isOpen,
  onClose,
  recordToEdit,
  defaultOriginCity = 'QUEIMADOS',
  cities,
  onSave
}) => {
  const [client, setClient] = useState('Mercado Livre');
  const [originCity, setOriginCity] = useState(defaultOriginCity);
  const [originCode, setOriginCode] = useState('SRJ2');
  const [destinationCity, setDestinationCity] = useState('SÃO JOÃO DE MERITI');
  const [destinationCode, setDestinationCode] = useState('BRRJ02');
  const [vehicleType, setVehicleType] = useState('CARRETA CASA');
  const [customVehicle, setCustomVehicle] = useState('');
  const [totalValue, setTotalValue] = useState('R$ 1.000,00');
  const [differential, setDifferential] = useState<Differential>('NORMAL');

  useEffect(() => {
    if (recordToEdit) {
      setClient(recordToEdit.client);
      setOriginCity(recordToEdit.originCity);
      setOriginCode(recordToEdit.originCode);
      setDestinationCity(recordToEdit.destinationCity);
      setDestinationCode(recordToEdit.destinationCode);
      if (VEHICLE_OPTIONS.includes(recordToEdit.vehicleType)) {
        setVehicleType(recordToEdit.vehicleType);
        setCustomVehicle('');
      } else {
        setVehicleType('CUSTOM');
        setCustomVehicle(recordToEdit.vehicleType);
      }
      setTotalValue(recordToEdit.totalValue);
      setDifferential(recordToEdit.differential);
    } else {
      setClient('Mercado Livre');
      setOriginCity(defaultOriginCity);
      // Pick matching code
      const orig = cities.find(c => c.name.toUpperCase() === defaultOriginCity.toUpperCase());
      setOriginCode(orig?.codes[0]?.code || 'SRJ2');
      setDestinationCity('SÃO JOÃO DE MERITI');
      setDestinationCode('BRRJ02');
      setVehicleType('CARRETA CASA');
      setCustomVehicle('');
      setTotalValue('R$ 1.000,00');
      setDifferential('NORMAL');
    }
  }, [recordToEdit, defaultOriginCity, cities]);

  // When origin city changes, update origin code
  const handleOriginChange = (cName: string) => {
    setOriginCity(cName);
    const found = cities.find(c => c.name.toUpperCase() === cName.toUpperCase());
    if (found && found.codes.length > 0) {
      setOriginCode(found.codes[0].code);
    }
  };

  // When destination city changes, update destination code
  const handleDestinationChange = (cName: string) => {
    setDestinationCity(cName);
    const found = cities.find(c => c.name.toUpperCase() === cName.toUpperCase());
    if (found && found.codes.length > 0) {
      setDestinationCode(found.codes[0].code);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalVehicle = vehicleType === 'CUSTOM' ? (customVehicle.trim() || 'CARRETA CASA') : vehicleType;

    onSave({
      id: recordToEdit?.id,
      client,
      originCity: originCity.toUpperCase().trim(),
      originCode: originCode.toUpperCase().trim(),
      destinationCity: destinationCity.toUpperCase().trim(),
      destinationCode: destinationCode.toUpperCase().trim(),
      vehicleType: finalVehicle,
      totalValue,
      differential,
      reviewStatus: 'REVISADO'
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl flex flex-col overflow-hidden text-neutral-100">
        {/* Header */}
        <div className="px-6 py-4 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-red-600/20 text-red-500 rounded-lg">
              {recordToEdit ? <Edit className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-base font-bold text-white uppercase tracking-wide">
                {recordToEdit ? 'EDITAR REGISTRO DE ROTA' : 'ADICIONAR NOVA ROTA'}
              </h2>
              <p className="text-xs text-neutral-400">
                Padrão estrutural de 8 colunas da Monfredini Transportes
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block text-neutral-300 font-bold mb-1">Cliente</label>
            <input
              type="text"
              value={client}
              onChange={e => setClient(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-medium focus:outline-none focus:border-red-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-300 font-bold mb-1">Cidade Origem</label>
              <select
                value={originCity}
                onChange={e => handleOriginChange(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-bold uppercase focus:outline-none focus:border-red-500"
              >
                {cities.map(c => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-neutral-300 font-bold mb-1">Sigla Origem</label>
              <input
                type="text"
                value={originCode}
                onChange={e => setOriginCode(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-mono font-bold uppercase focus:outline-none focus:border-red-500"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-300 font-bold mb-1">Cidade Destino</label>
              <select
                value={destinationCity}
                onChange={e => handleDestinationChange(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-bold uppercase focus:outline-none focus:border-red-500"
              >
                {cities.map(c => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-neutral-300 font-bold mb-1">Sigla Destino</label>
              <input
                type="text"
                value={destinationCode}
                onChange={e => setDestinationCode(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-mono font-bold uppercase focus:outline-none focus:border-red-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-neutral-300 font-bold mb-1">Perfil do Veículo (Tipo)</label>
            <select
              value={vehicleType}
              onChange={e => setVehicleType(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-bold focus:outline-none focus:border-red-500"
            >
              {VEHICLE_OPTIONS.map(v => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
              <option value="CUSTOM">Outro Perfil (Digitar Manuscrito)</option>
            </select>

            {vehicleType === 'CUSTOM' && (
              <input
                type="text"
                placeholder="Digite a descrição exata do perfil..."
                value={customVehicle}
                onChange={e => setCustomVehicle(e.target.value)}
                className="w-full mt-2 bg-neutral-950 border border-red-500 rounded px-3 py-1.5 text-white font-bold uppercase focus:outline-none"
                autoFocus
              />
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-300 font-bold mb-1">Valor Total</label>
              <input
                type="text"
                placeholder="R$ 1.000,00 ou -"
                value={totalValue}
                onChange={e => setTotalValue(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-mono font-extrabold focus:outline-none focus:border-red-500"
                required
              />
            </div>

            <div>
              <label className="block text-neutral-300 font-bold mb-1">Diferencial</label>
              <select
                value={differential}
                onChange={e => setDifferential(e.target.value as Differential)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-1.5 text-white font-bold focus:outline-none focus:border-red-500"
              >
                <option value="NORMAL">NORMAL</option>
                <option value="CPL">CPL</option>
                <option value="CIRCUITO">CIRCUITO</option>
                <option value="-">-</option>
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded font-semibold text-xs"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white rounded font-bold text-xs shadow-md transition-all"
            >
              Salvar Registro
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
