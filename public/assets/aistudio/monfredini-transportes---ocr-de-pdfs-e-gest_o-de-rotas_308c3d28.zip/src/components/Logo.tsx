import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md', showSubtitle = true }) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24'
  };

  const titleSizes = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl',
    xl: 'text-3xl'
  };

  const subSizes = {
    sm: 'text-[9px]',
    md: 'text-xs',
    lg: 'text-sm',
    xl: 'text-base'
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Mountain Peak Geometric Chrome Emblem */}
      <div className={`relative shrink-0 ${iconSizes[size]}`}>
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-md">
          {/* Outer triangle gradient */}
          <defs>
            <linearGradient id="chrome1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="45%" stopColor="#CBD5E1" />
              <stop offset="55%" stopColor="#94A3B8" />
              <stop offset="100%" stopColor="#64748B" />
            </linearGradient>
            <linearGradient id="chrome2" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#F8FAFC" />
              <stop offset="60%" stopColor="#94A3B8" />
              <stop offset="100%" stopColor="#475569" />
            </linearGradient>
            <linearGradient id="redAccent" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#DC2626" />
              <stop offset="100%" stopColor="#991B1B" />
            </linearGradient>
          </defs>

          {/* Left Peak */}
          <path d="M50 12 L15 78 L32 78 L50 42 L68 78 L85 78 Z" fill="url(#chrome1)" />
          {/* Inner Sharp Shading Facet */}
          <path d="M50 12 L50 42 L32 78 L15 78 Z" fill="url(#chrome2)" opacity="0.85" />
          {/* Peak Cutout Notch */}
          <path d="M50 28 L36 60 L64 60 Z" fill="#0B1320" />
          {/* Sleek bottom chevron */}
          <path d="M26 84 L50 74 L74 84 L50 80 Z" fill="url(#redAccent)" />
        </svg>
      </div>

      {/* Typography */}
      <div className="flex flex-col leading-none">
        <span className={`font-extrabold tracking-tight text-white font-sans ${titleSizes[size]}`}>
          Monfredini
        </span>
        {showSubtitle && (
          <span className={`font-bold tracking-widest text-red-500 uppercase ${subSizes[size]} mt-0.5`}>
            transportes
          </span>
        )}
      </div>
    </div>
  );
};
