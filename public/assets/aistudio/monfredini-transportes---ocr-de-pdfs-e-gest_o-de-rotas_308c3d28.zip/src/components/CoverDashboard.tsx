import React from 'react';
import { Logo } from './Logo.js';
import { City, Stats } from '../types.js';
import {
  MapPin,
  Route as RouteIcon,
  Truck,
  BarChart3,
  FileUp,
  ClipboardCheck,
  Download,
  Building2,
  Sparkles,
  Layers
} from 'lucide-react';

interface CoverDashboardProps {
  stats: Stats;
  cities: City[];
  selectedCityName: string;
  onSelectCity: (cityName: string) => void;
  onOpenImport: () => void;
  onOpenReview: () => void;
  onOpenExport: () => void;
  onOpenCities: () => void;
  onGenerateSampleSlip: () => void;
  isGeneratingSample: boolean;
}

export const CoverDashboard: React.FC<CoverDashboardProps> = ({
  stats,
  cities,
  selectedCityName,
  onSelectCity,
  onOpenImport,
  onOpenReview,
  onOpenExport,
  onOpenCities,
  onGenerateSampleSlip,
  isGeneratingSample
}) => {
  return (
    <div className="relative flex flex-col justify-between w-full h-full bg-neutral-950 text-white overflow-y-auto p-5 sm:p-7 border-r border-neutral-800">
      {/* Background Graphic Layer */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-20 overflow-hidden">
        <img
          src="/assets/aistudio/Painel_de_Rotas_Monfredini_Transportes_4e1a4e1a.png"
          alt="Monfredini Background"
          className="w-full h-full object-cover filter brightness-50"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/90 to-transparent" />
      </div>

      <div className="relative z-10 space-y-6">
        {/* Monfredini Logo Header */}
        <div className="pt-2">
          <Logo size="lg" />
        </div>

        {/* Title Block matching reference */}
        <div className="space-y-1">
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white uppercase font-sans">
            TABELA DE ROTAS
          </h1>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-red-600 uppercase font-sans">
            MERCADO LIVRE
          </h2>
          <p className="text-xs sm:text-sm font-semibold text-neutral-400 tracking-wider uppercase">
            COTAÇÕES E VALORES DE TRANSPORTE
          </p>
        </div>

        {/* 3 Stat Cards matching screenshot: CIDADES, ROTAS, VEICULOS */}
        <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
          {/* CIDADES */}
          <div className="bg-neutral-900/90 border border-neutral-800 rounded-lg p-3 sm:p-4 text-center flex flex-col items-center justify-center shadow-lg hover:border-neutral-700 transition-colors">
            <MapPin className="w-5 h-5 text-red-500 mb-1" />
            <span className="text-[10px] sm:text-xs font-bold text-neutral-400 uppercase tracking-wider">
              CIDADES
            </span>
            <span className="text-xl sm:text-2xl font-black text-white font-mono mt-0.5 tabular-nums">
              {stats.totalCities}
            </span>
          </div>

          {/* ROTAS */}
          <div className="bg-neutral-900/90 border border-neutral-800 rounded-lg p-3 sm:p-4 text-center flex flex-col items-center justify-center shadow-lg hover:border-neutral-700 transition-colors">
            <RouteIcon className="w-5 h-5 text-red-500 mb-1" />
            <span className="text-[10px] sm:text-xs font-bold text-neutral-400 uppercase tracking-wider">
              ROTAS
            </span>
            <span className="text-xl sm:text-2xl font-black text-white font-mono mt-0.5 tabular-nums">
              {stats.totalRoutes}
            </span>
          </div>

          {/* VEÍCULOS */}
          <div className="bg-neutral-900/90 border border-neutral-800 rounded-lg p-3 sm:p-4 text-center flex flex-col items-center justify-center shadow-lg hover:border-neutral-700 transition-colors">
            <Truck className="w-5 h-5 text-red-500 mb-1" />
            <span className="text-[10px] sm:text-xs font-bold text-neutral-400 uppercase tracking-wider">
              VEÍCULOS
            </span>
            <span className="text-xl sm:text-2xl font-black text-white font-mono mt-0.5 tabular-nums">
              {stats.vehicleProfilesCount}
            </span>
            <span className="text-[9px] text-neutral-400 uppercase">POR ROTA</span>
          </div>
        </div>

        {/* ACESSO RÁPIDO POR CIDADE Section matching reference */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-red-500" />
            <div>
              <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">
                ACESSO RÁPIDO POR CIDADE
              </h3>
              <p className="text-[11px] text-neutral-400">
                Clique na cidade abaixo para ir diretamente para a planilha
              </p>
            </div>
          </div>

          {/* Cities Grid of Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {cities
              .filter(c => c.active)
              .map(city => {
                const isSelected = selectedCityName === city.name;
                return (
                  <button
                    key={city.id}
                    onClick={() => onSelectCity(city.name)}
                    className={`px-2.5 py-2 rounded text-xs font-bold uppercase tracking-wider transition-all text-center border ${
                      isSelected
                        ? 'bg-red-600 text-white border-red-500 shadow-md ring-1 ring-red-400'
                        : 'bg-neutral-900/90 text-neutral-300 hover:text-white border-neutral-800 hover:border-neutral-700 hover:bg-neutral-800'
                    }`}
                  >
                    {city.name}
                  </button>
                );
              })}
          </div>
        </div>

        {/* Main Operational Actions */}
        <div className="space-y-2 pt-2">
          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
            AÇÕES DO SISTEMA
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onOpenImport}
              className="flex items-center justify-center gap-2 px-3 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-bold transition-all shadow-md"
            >
              <FileUp className="w-4 h-4" />
              <span>Importar PDFs</span>
            </button>

            <button
              onClick={onOpenReview}
              className="relative flex items-center justify-center gap-2 px-3 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 rounded text-xs font-bold transition-all border border-neutral-700"
            >
              <ClipboardCheck className="w-4 h-4 text-amber-400" />
              <span>Conferência OCR</span>
              {stats.pendingReviews > 0 && (
                <span className="px-1.5 py-0.5 bg-amber-500 text-neutral-950 text-[10px] font-black rounded-full">
                  {stats.pendingReviews}
                </span>
              )}
            </button>

            <button
              onClick={onOpenExport}
              className="flex items-center justify-center gap-2 px-3 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 rounded text-xs font-bold transition-all border border-neutral-700"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Exportar Excel</span>
            </button>

            <button
              onClick={onOpenCities}
              className="flex items-center justify-center gap-2 px-3 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 rounded text-xs font-bold transition-all border border-neutral-700"
            >
              <Building2 className="w-4 h-4 text-blue-400" />
              <span>Cidades e Códigos</span>
            </button>
          </div>

          {/* Test Drive Button for Instant Handwritten Slip OCR demonstration */}
          <div className="pt-2">
            <button
              onClick={onGenerateSampleSlip}
              disabled={isGeneratingSample}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white rounded text-xs font-medium border border-neutral-800 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>
                {isGeneratingSample
                  ? 'Gerando e Processando OCR...'
                  : 'Testar OCR com Folha Manuscrita de Exemplo'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="relative z-10 pt-6 mt-6 border-t border-neutral-900 text-[10px] text-neutral-500 flex items-center justify-between">
        <span>Monfredini Transportes © 2026</span>
        <span className="font-mono">Gemini 3.8 Flash OCR</span>
      </div>
    </div>
  );
};
