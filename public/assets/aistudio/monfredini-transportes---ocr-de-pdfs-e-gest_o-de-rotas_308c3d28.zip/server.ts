import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import multer from 'multer';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { db, UPLOADS_DIR } from './server/db.js';
import { processDocumentWithGemini, parseCurrencyInput } from './server/ocr.js';
import { generateRoutesExcel } from './server/excel.js';
import { createSampleTransportPdf } from './server/samplePdf.js';
import { RouteRecord, UploadedDocument } from './server/types.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Body parsers
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Multer storage
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB
});

// Serve uploaded storage files if requested
app.use('/storage/uploads', express.static(UPLOADS_DIR));

// ----------------- API ROUTES ----------------- //

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Stats
app.get('/api/stats', (req, res) => {
  try {
    const stats = db.getStats();
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Cities
app.get('/api/cities', (req, res) => {
  try {
    const cities = db.getCities();
    res.json(cities);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/cities', (req, res) => {
  try {
    const { name, state, codes, active } = req.body;
    if (!name) return res.status(400).json({ error: 'Nome da cidade é obrigatório' });
    const codeList = Array.isArray(codes) ? codes : [codes].filter(Boolean);
    const city = db.addCity({ name, state: state || 'BR', codes: codeList, active });
    res.status(201).json(city);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/cities/:id', (req, res) => {
  try {
    const updated = db.updateCity(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Cidade não encontrada' });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/cities/:id', (req, res) => {
  try {
    const success = db.deleteCity(req.params.id);
    if (!success) return res.status(404).json({ error: 'Cidade não encontrada' });
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Routes
app.get('/api/routes', (req, res) => {
  try {
    const { originCity, destinationCity, differential, reviewStatus, documentId, search } = req.query;
    const routes = db.getRoutes({
      originCity: originCity as string,
      destinationCity: destinationCity as string,
      differential: differential as string,
      reviewStatus: reviewStatus as string,
      documentId: documentId as string,
      search: search as string
    });
    res.json(routes);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/routes', (req, res) => {
  try {
    const body = req.body;
    const { formatted, numeric } = parseCurrencyInput(body.totalValue);
    const newRecord: RouteRecord = {
      id: `rec-${crypto.randomBytes(8).toString('hex')}`,
      documentId: body.documentId || 'manual',
      documentPageId: 'manual',
      documentName: body.documentName || 'Registro Manual',
      pageNumber: 1,
      client: body.client || 'Mercado Livre',
      originCity: (body.originCity || '').toUpperCase().trim(),
      originCode: (body.originCode || '').toUpperCase().trim(),
      destinationCity: (body.destinationCity || '').toUpperCase().trim(),
      destinationCode: (body.destinationCode || '').toUpperCase().trim(),
      vehicleType: body.vehicleType,
      totalValue: formatted,
      numericValue: numeric,
      differential: body.differential || 'NORMAL',
      ocrConfidence: 100,
      reviewStatus: 'REVISADO',
      notes: body.notes || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    db.addRouteRecords([newRecord]);
    res.status(201).json(newRecord);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/routes/:id', (req, res) => {
  try {
    const updates = { ...req.body };
    if (updates.totalValue !== undefined) {
      const { formatted, numeric } = parseCurrencyInput(updates.totalValue);
      updates.totalValue = formatted;
      updates.numericValue = numeric;
    }
    const updated = db.updateRouteRecord(req.params.id, updates);
    if (!updated) return res.status(404).json({ error: 'Registro de rota não encontrado' });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/routes/:id', (req, res) => {
  try {
    const success = db.deleteRouteRecord(req.params.id);
    if (!success) return res.status(404).json({ error: 'Registro não encontrado' });
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/routes/batch-approve', (req, res) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'IDs devem ser uma lista não vazia' });
    }
    const count = db.batchUpdateStatus(ids, 'REVISADO');
    res.json({ success: true, count });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Documents
app.get('/api/documents', (req, res) => {
  try {
    const docs = db.getDocuments();
    res.json(docs);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/documents/:id', (req, res) => {
  try {
    const doc = db.getDocumentById(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Documento não encontrado' });
    const records = db.getRoutes({ documentId: doc.id });
    res.json({ ...doc, records });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Upload PDFs (Single or Multiple)
app.post('/api/documents/upload', upload.array('files'), async (req, res) => {
  try {
    const files = req.files as Express.Multer.File[];
    if (!files || files.length === 0) {
      return res.status(400).json({ error: 'Nenhum arquivo enviado.' });
    }

    const results: any[] = [];

    for (const file of files) {
      // 1. Calculate file hash for idempotency
      const fileHash = crypto.createHash('sha256').update(file.buffer).digest('hex');

      // 2. Check if already imported
      const existingDoc = db.getDocumentByHash(fileHash);
      if (existingDoc && !req.query.force) {
        results.push({
          filename: file.originalname,
          status: 'DUPLICATE',
          message: 'Documento já importado anteriormente. Ignorado para evitar duplicidades.',
          documentId: existingDoc.id
        });
        continue;
      }

      // 3. Save physical file
      const docId = `doc-${crypto.randomBytes(6).toString('hex')}`;
      const safeFilename = `${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
      const storagePath = path.join(UPLOADS_DIR, safeFilename);
      fs.writeFileSync(storagePath, file.buffer);

      // 4. Create document record
      const docRecord: UploadedDocument = {
        id: docId,
        filename: file.originalname,
        fileHash,
        fileSize: file.size,
        storagePath: `storage/uploads/${safeFilename}`,
        pageCount: 1, // basic estimate, updated after processing
        processingStatus: 'PROCESSING',
        autoConfirmed: db.getSettings().autoConfirmOcr,
        totalRecordsExtracted: 0,
        uploadedAt: new Date().toISOString()
      };
      db.addDocument(docRecord);

      try {
        // 5. Run OCR with Gemini 3.8 Flash
        const extractedRoutes = await processDocumentWithGemini(
          file.buffer,
          file.mimetype || 'application/pdf',
          file.originalname,
          docId
        );

        // Update document as completed
        db.updateDocument(docId, {
          processingStatus: 'COMPLETED',
          totalRecordsExtracted: extractedRoutes.length,
          processedAt: new Date().toISOString()
        });

        results.push({
          documentId: docId,
          filename: file.originalname,
          status: 'SUCCESS',
          originCity: extractedRoutes[0]?.originCity || 'RIO DE JANEIRO',
          recordsExtracted: extractedRoutes.length
        });
      } catch (procErr: any) {
        console.error(`Error processing file ${file.originalname}:`, procErr);
        db.updateDocument(docId, {
          processingStatus: 'ERROR',
          errorMessage: procErr.message || 'Erro no processamento OCR',
          processedAt: new Date().toISOString()
        });
        results.push({
          documentId: docId,
          filename: file.originalname,
          status: 'ERROR',
          error: procErr.message
        });
      }
    }

    res.json({ results });
  } catch (err: any) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Reprocess document
app.post('/api/documents/:id/reprocess', async (req, res) => {
  try {
    const doc = db.getDocumentById(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Documento não encontrado' });

    const fullPath = path.resolve(__dirname, doc.storagePath);
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: 'Arquivo original não encontrado no servidor' });
    }

    const fileBuffer = fs.readFileSync(fullPath);
    db.updateDocument(doc.id, { processingStatus: 'PROCESSING' });

    const routes = await processDocumentWithGemini(
      fileBuffer,
      'application/pdf',
      doc.filename,
      doc.id
    );

    db.updateDocument(doc.id, {
      processingStatus: 'COMPLETED',
      totalRecordsExtracted: routes.length,
      processedAt: new Date().toISOString()
    });

    res.json({ success: true, count: routes.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Generate and import sample transport slip PDF with 1-click
app.post('/api/documents/generate-sample', async (req, res) => {
  try {
    const { origin, destination, differential } = req.body;
    const sampleBuffer = await createSampleTransportPdf({
      origin: origin || 'QUEIMADOS',
      destination: destination || 'EXTREMA',
      differential: differential || 'CPL'
    });

    const filename = `COTAÇÃO_MANUSCRITA_${(origin || 'QUEIMADOS')}_${(destination || 'EXTREMA')}_${Date.now()}.pdf`;
    const docId = `doc-sample-${crypto.randomBytes(4).toString('hex')}`;
    const fileHash = crypto.createHash('sha256').update(sampleBuffer).digest('hex');
    const safeFilename = `${Date.now()}-${filename}`;
    const storagePath = path.join(UPLOADS_DIR, safeFilename);

    fs.writeFileSync(storagePath, sampleBuffer);

    const docRecord: UploadedDocument = {
      id: docId,
      filename,
      fileHash,
      fileSize: sampleBuffer.length,
      storagePath: `storage/uploads/${safeFilename}`,
      pageCount: 1,
      processingStatus: 'PROCESSING',
      autoConfirmed: false,
      totalRecordsExtracted: 0,
      uploadedAt: new Date().toISOString()
    };
    db.addDocument(docRecord);

    const routes = await processDocumentWithGemini(
      sampleBuffer,
      'application/pdf',
      filename,
      docId
    );

    db.updateDocument(docId, {
      processingStatus: 'COMPLETED',
      totalRecordsExtracted: routes.length,
      processedAt: new Date().toISOString()
    });

    res.json({
      success: true,
      documentId: docId,
      filename,
      recordsCount: routes.length
    });
  } catch (err: any) {
    console.error('Error creating sample PDF:', err);
    res.status(500).json({ error: err.message });
  }
});

// Export Excel
app.post('/api/export-excel', async (req, res) => {
  try {
    const { city, differential, onlyReviewed } = req.body;
    const excelBuffer = await generateRoutesExcel({
      city,
      differential,
      onlyReviewed
    });

    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `Tabela_Rotas_Monfredini_${city || 'Todas'}_${timestamp}.xlsx`;

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(excelBuffer);
  } catch (err: any) {
    console.error('Excel generation error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Settings
app.get('/api/settings', (req, res) => {
  res.json(db.getSettings());
});

app.put('/api/settings', (req, res) => {
  try {
    const updated = db.updateSettings(req.body);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ----------------- VITE INTEGRATION ----------------- //
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Monfredini Transportes Server running on port ${PORT}`);
  });
}

startServer();
