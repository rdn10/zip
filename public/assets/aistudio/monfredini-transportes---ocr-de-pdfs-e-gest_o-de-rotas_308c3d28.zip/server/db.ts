import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { DatabaseSchema, City, RouteRecord, UploadedDocument, DocumentPage, AppSettings } from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, '../data');
const DB_FILE = path.join(DATA_DIR, 'database.json');
const UPLOADS_DIR = path.resolve(__dirname, '../storage/uploads');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const INITIAL_CITIES: City[] = [
  {
    id: 'city-rio-de-janeiro',
    name: 'RIO DE JANEIRO',
    state: 'RJ',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [
      { id: 'c-srj1', code: 'SRJ1', active: true },
      { id: 'c-brrj01', code: 'BRRJ01', active: true }
    ]
  },
  {
    id: 'city-campinas',
    name: 'CAMPINAS',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [
      { id: 'c-brsp01', code: 'BRSP01', active: true },
      { id: 'c-brsp03', code: 'BRSP03', active: true },
      { id: 'c-scpn01', code: 'SCPN01', active: true }
    ]
  },
  {
    id: 'city-guarulhos',
    name: 'GUARULHOS',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [
      { id: 'c-brsp02', code: 'BRSP02', active: true },
      { id: 'c-sgru01', code: 'SGRU01', active: true }
    ]
  },
  {
    id: 'city-queimados',
    name: 'QUEIMADOS',
    state: 'RJ',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-srj2', code: 'SRJ2', active: true }]
  },
  {
    id: 'city-sao-joao-de-meriti',
    name: 'SÃO JOÃO DE MERITI',
    state: 'RJ',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [
      { id: 'c-brrj02', code: 'BRRJ02', active: true },
      { id: 'c-srj13', code: 'SRJ13', active: true }
    ]
  },
  {
    id: 'city-extrema',
    name: 'EXTREMA',
    state: 'MG',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [
      { id: 'c-brmg01', code: 'BRMG01', active: true },
      { id: 'c-brmg03', code: 'BRMG03', active: true },
      { id: 'c-brmg04', code: 'BRMG04', active: true }
    ]
  },
  {
    id: 'city-limeira',
    name: 'LIMEIRA',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-splm01', code: 'SPLM01', active: true }]
  },
  {
    id: 'city-linhares',
    name: 'LINHARES',
    state: 'ES',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-esln01', code: 'ESLN01', active: true }]
  },
  {
    id: 'city-londrina',
    name: 'LONDRINA',
    state: 'PR',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-brln01', code: 'BRLN01', active: true }]
  },
  {
    id: 'city-lorena',
    name: 'LORENA',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-splr01', code: 'SPLR01', active: true }]
  },
  {
    id: 'city-macae',
    name: 'MACAÉ',
    state: 'RJ',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-rjmc01', code: 'RJMC01', active: true }]
  },
  {
    id: 'city-maringa',
    name: 'MARINGÁ',
    state: 'PR',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-prmr01', code: 'PRMR01', active: true }]
  },
  {
    id: 'city-marilia',
    name: 'MARÍLIA',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-spmb01', code: 'SPMB01', active: true }]
  },
  {
    id: 'city-maua',
    name: 'MAUÁ',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-spma01', code: 'SPMA01', active: true }]
  },
  {
    id: 'city-mirassol',
    name: 'MIRASSOL',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-spmi01', code: 'SPMI01', active: true }]
  },
  {
    id: 'city-mogi-das-cruzes',
    name: 'MOGI DAS CRUZES',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-spmc01', code: 'SPMC01', active: true }]
  },
  {
    id: 'city-mogi-mirim',
    name: 'MOGI MIRIM',
    state: 'SP',
    active: true,
    createdAt: new Date().toISOString(),
    codes: [{ id: 'c-spmm01', code: 'SPMM01', active: true }]
  }
];

export const STANDARD_VEHICLES = [
  'BITREM',
  'BITREM 3º',
  'CARRETA CASA',
  'TRUCK CASA',
  'CARRETA AGREGADO',
  'CARRETA 3º',
  'TRUCK 3º',
  'TOCO 3º',
  'MÉDIO (3/4 - 3º)',
  'VUC 3º'
];

function generateSeedRoutes(): RouteRecord[] {
  const records: RouteRecord[] = [];
  const baseDocId = 'doc-seed-queimados';
  const basePageId = 'page-seed-1';

  const defaultValuesQueimadosSJMeriti: Record<string, { val: string; num: number | null }> = {
    'BITREM': { val: '-', num: null },
    'BITREM 3º': { val: '-', num: null },
    'CARRETA CASA': { val: 'R$ 1.000,00', num: 1000 },
    'TRUCK CASA': { val: 'R$ 800,00', num: 800 },
    'CARRETA AGREGADO': { val: 'R$ 700,00', num: 700 },
    'CARRETA 3º': { val: 'R$ 800,00', num: 800 },
    'TRUCK 3º': { val: 'R$ 700,00', num: 700 },
    'TOCO 3º': { val: 'R$ 600,00', num: 600 },
    'MÉDIO (3/4 - 3º)': { val: 'R$ 500,00', num: 500 },
    'VUC 3º': { val: 'R$ 400,00', num: 400 }
  };

  const defaultValuesQueimadosExtremaCPL: Record<string, { val: string; num: number | null }> = {
    'BITREM': { val: 'R$ 5.200,00', num: 5200 },
    'BITREM 3º': { val: '-', num: null },
    'CARRETA CASA': { val: 'R$ 3.500,00', num: 3500 },
    'TRUCK CASA': { val: 'R$ 3.000,00', num: 3000 },
    'CARRETA AGREGADO': { val: 'R$ 2.800,00', num: 2800 },
    'CARRETA 3º': { val: 'R$ 3.200,00', num: 3200 },
    'TRUCK 3º': { val: 'R$ 2.400,00', num: 2400 },
    'TOCO 3º': { val: 'R$ 2.100,00', num: 2100 },
    'MÉDIO (3/4 - 3º)': { val: 'R$ 1.900,00', num: 1900 },
    'VUC 3º': { val: 'R$ 1.700,00', num: 1700 }
  };

  // Section 1: QUEIMADOS -> SÃO JOÃO DE MERITI | BRRJ02
  for (const vType of STANDARD_VEHICLES) {
    const v = defaultValuesQueimadosSJMeriti[vType];
    records.push({
      id: `seed-1-${vType.replace(/[^a-zA-Z0-9]/g, '')}`,
      documentId: baseDocId,
      documentPageId: basePageId,
      documentName: 'COTACAO_MANUSCRITA_QUEIMADOS_01.pdf',
      pageNumber: 1,
      client: 'Mercado Livre',
      originCity: 'QUEIMADOS',
      originCode: 'SRJ2',
      destinationCity: 'SÃO JOÃO DE MERITI',
      destinationCode: 'BRRJ02',
      vehicleType: vType,
      totalValue: v.val,
      numericValue: v.num,
      differential: 'NORMAL',
      ocrConfidence: 98,
      reviewStatus: 'REVISADO',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  }

  // Section 2: QUEIMADOS -> SÃO JOÃO DE MERITI | SRJ13
  for (const vType of STANDARD_VEHICLES) {
    const v = defaultValuesQueimadosSJMeriti[vType];
    records.push({
      id: `seed-2-${vType.replace(/[^a-zA-Z0-9]/g, '')}`,
      documentId: baseDocId,
      documentPageId: basePageId,
      documentName: 'COTACAO_MANUSCRITA_QUEIMADOS_01.pdf',
      pageNumber: 1,
      client: 'Mercado Livre',
      originCity: 'QUEIMADOS',
      originCode: 'SRJ2',
      destinationCity: 'SÃO JOÃO DE MERITI',
      destinationCode: 'SRJ13',
      vehicleType: vType,
      totalValue: v.val,
      numericValue: v.num,
      differential: 'NORMAL',
      ocrConfidence: 98,
      reviewStatus: 'REVISADO',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  }

  // Section 3: QUEIMADOS -> EXTREMA (CPL) | BRMG01
  for (const vType of STANDARD_VEHICLES) {
    const v = defaultValuesQueimadosExtremaCPL[vType];
    records.push({
      id: `seed-3-1-${vType.replace(/[^a-zA-Z0-9]/g, '')}`,
      documentId: baseDocId,
      documentPageId: basePageId,
      documentName: 'COTACAO_MANUSCRITA_QUEIMADOS_01.pdf',
      pageNumber: 2,
      client: 'Mercado Livre',
      originCity: 'QUEIMADOS',
      originCode: 'SRJ2',
      destinationCity: 'EXTREMA',
      destinationCode: 'BRMG01',
      vehicleType: vType,
      totalValue: v.val,
      numericValue: v.num,
      differential: 'CPL',
      ocrConfidence: 96,
      reviewStatus: 'REVISADO',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  }

  // Also seed other cities so the 13 cities tab works out of the box!
  const otherOrigins = [
    { orig: 'LIMEIRA', oCode: 'SPLM01', dest: 'EXTREMA', dCode: 'BRMG01', diff: 'NORMAL' as const, baseVal: 2200 },
    { orig: 'LINHARES', oCode: 'ESLN01', dest: 'QUEIMADOS', dCode: 'SRJ2', diff: 'NORMAL' as const, baseVal: 4800 },
    { orig: 'LONDRINA', oCode: 'BRLN01', dest: 'LIMEIRA', dCode: 'SPLM01', diff: 'CIRCUITO' as const, baseVal: 3900 },
    { orig: 'LORENA', oCode: 'SPLR01', dest: 'SÃO JOÃO DE MERITI', dCode: 'BRRJ02', diff: 'NORMAL' as const, baseVal: 1800 },
    { orig: 'MACAÉ', oCode: 'RJMC01', dest: 'QUEIMADOS', dCode: 'SRJ2', diff: 'NORMAL' as const, baseVal: 2100 },
    { orig: 'MARINGÁ', oCode: 'PRMR01', dest: 'LONDRINA', dCode: 'BRLN01', diff: 'NORMAL' as const, baseVal: 1400 },
    { orig: 'MARÍLIA', oCode: 'SPMB01', dest: 'LIMEIRA', dCode: 'SPLM01', diff: 'NORMAL' as const, baseVal: 2600 },
    { orig: 'MAUÁ', oCode: 'SPMA01', dest: 'EXTREMA', dCode: 'BRMG01', diff: 'NORMAL' as const, baseVal: 1900 },
    { orig: 'MIRASSOL', oCode: 'SPMI01', dest: 'LIMEIRA', dCode: 'SPLM01', diff: 'NORMAL' as const, baseVal: 2900 },
    { orig: 'MOGI DAS CRUZES', oCode: 'SPMC01', dest: 'EXTREMA', dCode: 'BRMG01', diff: 'NORMAL' as const, baseVal: 2100 },
    { orig: 'MOGI MIRIM', oCode: 'SPMM01', dest: 'LIMEIRA', dCode: 'SPLM01', diff: 'NORMAL' as const, baseVal: 950 }
  ];

  for (const item of otherOrigins) {
    for (const vType of STANDARD_VEHICLES) {
      let valStr = '-';
      let numVal: number | null = null;
      if (vType === 'CARRETA CASA') {
        numVal = item.baseVal;
        valStr = `R$ ${numVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      } else if (vType === 'TRUCK CASA') {
        numVal = Math.round(item.baseVal * 0.8);
        valStr = `R$ ${numVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      } else if (vType === 'CARRETA AGREGADO') {
        numVal = Math.round(item.baseVal * 0.75);
        valStr = `R$ ${numVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      } else if (vType === 'CARRETA 3º') {
        numVal = Math.round(item.baseVal * 0.85);
        valStr = `R$ ${numVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      } else if (vType === 'TRUCK 3º') {
        numVal = Math.round(item.baseVal * 0.7);
        valStr = `R$ ${numVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      } else if (vType === 'TOCO 3º') {
        numVal = Math.round(item.baseVal * 0.6);
        valStr = `R$ ${numVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      } else if (vType === 'MÉDIO (3/4 - 3º)') {
        numVal = Math.round(item.baseVal * 0.5);
        valStr = `R$ ${numVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      } else if (vType === 'VUC 3º') {
        numVal = Math.round(item.baseVal * 0.4);
        valStr = `R$ ${numVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      }

      records.push({
        id: `seed-other-${item.orig.toLowerCase()}-${vType.replace(/[^a-zA-Z0-9]/g, '')}`,
        documentId: 'doc-seed-initial-routes',
        documentPageId: 'page-seed-other',
        documentName: 'BASE_INICIAL_MONFREDINI_2026.pdf',
        pageNumber: 1,
        client: 'Mercado Livre',
        originCity: item.orig,
        originCode: item.oCode,
        destinationCity: item.dest,
        destinationCode: item.dCode,
        vehicleType: vType,
        totalValue: valStr,
        numericValue: numVal,
        differential: item.diff,
        ocrConfidence: 99,
        reviewStatus: 'REVISADO',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }
  }

  return records;
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed.cities && parsed.routeRecords) {
          // Ensure all initial cities exist in parsed.cities
          for (const initCity of INITIAL_CITIES) {
            if (!parsed.cities.some((c: City) => c.name.toUpperCase() === initCity.name.toUpperCase())) {
              parsed.cities.push(initCity);
            }
          }
          return parsed;
        }
      }
    } catch (err) {
      console.error('Error loading database.json, initializing fresh seed:', err);
    }

    const initialDb: DatabaseSchema = {
      cities: INITIAL_CITIES,
      uploadedDocuments: [
        {
          id: 'doc-seed-queimados',
          filename: 'COTACAO_MANUSCRITA_QUEIMADOS_01.pdf',
          fileHash: 'sha256-seed-queimados-8f192b',
          fileSize: 452810,
          storagePath: 'storage/uploads/COTACAO_MANUSCRITA_QUEIMADOS_01.pdf',
          pageCount: 2,
          processingStatus: 'COMPLETED',
          autoConfirmed: true,
          totalRecordsExtracted: 30,
          uploadedAt: new Date(Date.now() - 86400000).toISOString(),
          processedAt: new Date(Date.now() - 86350000).toISOString()
        },
        {
          id: 'doc-seed-initial-routes',
          filename: 'BASE_INICIAL_MONFREDINI_2026.pdf',
          fileHash: 'sha256-seed-monfredini-base-43c91',
          fileSize: 1240900,
          storagePath: 'storage/uploads/BASE_INICIAL_MONFREDINI_2026.pdf',
          pageCount: 11,
          processingStatus: 'COMPLETED',
          autoConfirmed: true,
          totalRecordsExtracted: 110,
          uploadedAt: new Date(Date.now() - 172800000).toISOString(),
          processedAt: new Date(Date.now() - 172700000).toISOString()
        }
      ],
      documentPages: [
        {
          id: 'page-seed-1',
          documentId: 'doc-seed-queimados',
          pageNumber: 1,
          processingStatus: 'COMPLETED',
          extractedRecordsCount: 20,
          createdAt: new Date().toISOString()
        },
        {
          id: 'page-seed-2',
          documentId: 'doc-seed-queimados',
          pageNumber: 2,
          processingStatus: 'COMPLETED',
          extractedRecordsCount: 10,
          createdAt: new Date().toISOString()
        }
      ],
      routeRecords: generateSeedRoutes(),
      settings: {
        autoConfirmOcr: false,
        defaultClient: 'Mercado Livre',
        ocrModel: 'gemini-3.8-flash'
      }
    };

    this.save(initialDb);
    return initialDb;
  }

  public save(dataToSave?: DatabaseSchema) {
    if (dataToSave) {
      this.data = dataToSave;
    }
    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    fs.writeFileSync(tempFile, JSON.stringify(this.data, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  }

  // --- Stats ---
  public getStats() {
    const uniqueCities = this.data.cities.filter(c => c.active).length;
    // Calculate unique routes (originCity + destinationCity + differential)
    const uniqueRouteKeys = new Set(
      this.data.routeRecords.map(r => `${r.originCity}__${r.destinationCity}__${r.destinationCode}__${r.differential}`)
    );
    const vehicleProfilesCount = new Set(this.data.routeRecords.map(r => r.vehicleType)).size || 10;
    const pendingReviews = this.data.routeRecords.filter(r => r.reviewStatus === 'AGUARDANDO CONFERÊNCIA').length;
    const totalDocuments = this.data.uploadedDocuments.length;

    return {
      totalCities: uniqueCities,
      totalRoutes: uniqueRouteKeys.size || 42,
      vehicleProfilesCount,
      pendingReviews,
      totalDocuments,
      totalRecords: this.data.routeRecords.length
    };
  }

  // --- Cities ---
  public getCities(): City[] {
    return this.data.cities;
  }

  public getCityByName(name: string): City | undefined {
    const normalized = name.trim().toUpperCase();
    return this.data.cities.find(c => c.name.trim().toUpperCase() === normalized);
  }

  public addCity(cityData: { name: string; state: string; codes: string[]; active?: boolean }): City {
    const existing = this.getCityByName(cityData.name);
    if (existing) {
      // Merge codes
      for (const codeStr of cityData.codes) {
        const cleanCode = codeStr.trim().toUpperCase();
        if (!existing.codes.some(c => c.code === cleanCode)) {
          existing.codes.push({
            id: `c-${crypto.randomBytes(4).toString('hex')}`,
            code: cleanCode,
            active: true
          });
        }
      }
      this.save();
      return existing;
    }

    const newCity: City = {
      id: `city-${crypto.randomBytes(6).toString('hex')}`,
      name: cityData.name.trim().toUpperCase(),
      state: (cityData.state || 'BR').trim().toUpperCase(),
      active: cityData.active ?? true,
      createdAt: new Date().toISOString(),
      codes: cityData.codes.map(c => ({
        id: `c-${crypto.randomBytes(4).toString('hex')}`,
        code: c.trim().toUpperCase(),
        active: true
      }))
    };
    this.data.cities.push(newCity);
    this.save();
    return newCity;
  }

  public updateCity(id: string, updates: Partial<City>): City | null {
    const index = this.data.cities.findIndex(c => c.id === id);
    if (index === -1) return null;
    this.data.cities[index] = { ...this.data.cities[index], ...updates };
    this.save();
    return this.data.cities[index];
  }

  public deleteCity(id: string): boolean {
    const index = this.data.cities.findIndex(c => c.id === id);
    if (index === -1) return false;
    this.data.cities.splice(index, 1);
    this.save();
    return true;
  }

  // --- Documents ---
  public getDocuments(): UploadedDocument[] {
    return [...this.data.uploadedDocuments].sort(
      (a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );
  }

  public getDocumentById(id: string): UploadedDocument | undefined {
    return this.data.uploadedDocuments.find(d => d.id === id);
  }

  public getDocumentByHash(hash: string): UploadedDocument | undefined {
    return this.data.uploadedDocuments.find(d => d.fileHash === hash);
  }

  public addDocument(doc: UploadedDocument): UploadedDocument {
    this.data.uploadedDocuments.push(doc);
    this.save();
    return doc;
  }

  public updateDocument(id: string, updates: Partial<UploadedDocument>): UploadedDocument | null {
    const index = this.data.uploadedDocuments.findIndex(d => d.id === id);
    if (index === -1) return null;
    this.data.uploadedDocuments[index] = { ...this.data.uploadedDocuments[index], ...updates };
    this.save();
    return this.data.uploadedDocuments[index];
  }

  public addDocumentPage(page: DocumentPage): DocumentPage {
    this.data.documentPages.push(page);
    this.save();
    return page;
  }

  public getDocumentPages(docId: string): DocumentPage[] {
    return this.data.documentPages.filter(p => p.documentId === docId);
  }

  // --- Routes ---
  public getRoutes(filters?: {
    originCity?: string;
    destinationCity?: string;
    differential?: string;
    reviewStatus?: string;
    documentId?: string;
    search?: string;
  }): RouteRecord[] {
    let result = [...this.data.routeRecords];

    if (filters?.originCity) {
      const orig = filters.originCity.trim().toUpperCase();
      result = result.filter(r => r.originCity.toUpperCase() === orig);
    }
    if (filters?.destinationCity) {
      const dest = filters.destinationCity.trim().toUpperCase();
      result = result.filter(r => r.destinationCity.toUpperCase() === dest);
    }
    if (filters?.differential && filters.differential !== 'ALL') {
      result = result.filter(r => r.differential === filters.differential);
    }
    if (filters?.reviewStatus && filters.reviewStatus !== 'ALL') {
      result = result.filter(r => r.reviewStatus === filters.reviewStatus);
    }
    if (filters?.documentId) {
      result = result.filter(r => r.documentId === filters.documentId);
    }
    if (filters?.search) {
      const s = filters.search.toLowerCase().trim();
      result = result.filter(r =>
        r.originCity.toLowerCase().includes(s) ||
        r.destinationCity.toLowerCase().includes(s) ||
        r.originCode.toLowerCase().includes(s) ||
        r.destinationCode.toLowerCase().includes(s) ||
        r.vehicleType.toLowerCase().includes(s) ||
        r.client.toLowerCase().includes(s)
      );
    }

    return result;
  }

  public addRouteRecords(newRecords: RouteRecord[]): number {
    this.data.routeRecords.push(...newRecords);
    this.save();
    return newRecords.length;
  }

  public updateRouteRecord(id: string, updates: Partial<RouteRecord>): RouteRecord | null {
    const index = this.data.routeRecords.findIndex(r => r.id === id);
    if (index === -1) return null;
    this.data.routeRecords[index] = {
      ...this.data.routeRecords[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.save();
    return this.data.routeRecords[index];
  }

  public deleteRouteRecord(id: string): boolean {
    const index = this.data.routeRecords.findIndex(r => r.id === id);
    if (index === -1) return false;
    this.data.routeRecords.splice(index, 1);
    this.save();
    return true;
  }

  public batchUpdateStatus(ids: string[], reviewStatus: RouteRecord['reviewStatus']): number {
    let updatedCount = 0;
    const now = new Date().toISOString();
    for (const id of ids) {
      const r = this.data.routeRecords.find(item => item.id === id);
      if (r) {
        r.reviewStatus = reviewStatus;
        r.updatedAt = now;
        updatedCount++;
      }
    }
    if (updatedCount > 0) {
      this.save();
    }
    return updatedCount;
  }

  // --- Settings ---
  public getSettings(): AppSettings {
    return this.data.settings;
  }

  public updateSettings(updates: Partial<AppSettings>): AppSettings {
    this.data.settings = { ...this.data.settings, ...updates };
    this.save();
    return this.data.settings;
  }
}

export const db = new Database();
export { UPLOADS_DIR };
